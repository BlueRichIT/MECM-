(function () {
  "use strict";

  var state = {
    data: null,
    activeView: "overview",
    workload: "osd",
    timer: null,
    clockTimer: null,
    clientPage: 1
  };

  var workloadConfig = {
    osd: {
      key: "osd",
      type: ["OSD"],
      title: "OSD Deployments",
      eyebrow: "OPERATING SYSTEM DEPLOYMENT",
      heading: "Task sequence deployment status",
      copy: "Success, failure and in-progress state across active OSD task sequences.",
      listTitle: "OSD task sequences"
    },
    patching: {
      key: "patching",
      type: ["PATCH"],
      title: "Patching",
      eyebrow: "SOFTWARE UPDATES",
      heading: "Patch compliance status",
      copy: "Current compliance and enforcement results for software-update deployments.",
      listTitle: "Software-update deployments"
    },
    software: {
      key: "software",
      type: ["APP", "PACKAGE", "DISTRIBUTION"],
      title: "Software Distribution",
      eyebrow: "APPLICATIONS AND PACKAGES",
      heading: "Software distribution status",
      copy: "Application, package and program deployment results across managed devices.",
      listTitle: "Application and package deployments"
    }
  };

  function byId(id) { return document.getElementById(id); }
  function array(value) { return Array.isArray(value) ? value : []; }
  function number(value) {
    var parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  function formatNumber(value) { return number(value).toLocaleString(); }
  function safe(value) {
    return String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
  function text(id, value) {
    var element = byId(id);
    if (element) { element.textContent = value; }
  }
  function normalizedStatus(value) {
    var status = String(value || "Unknown").toLowerCase();
    if (["online", "healthy", "degraded", "warning", "offline", "critical"].indexOf(status) >= 0) {
      return status;
    }
    if (/fail|error|fatal|critical|offline/.test(status)) { return "critical"; }
    if (/warn|retry|progress|pending|degrad|attention/.test(status)) { return "warning"; }
    if (/online|healthy|success|install|compliant|complete|removed/.test(status)) { return "healthy"; }
    return "unknown";
  }
  function statusPill(value) {
    var css = normalizedStatus(value);
    return '<span class="status-pill ' + css + '"><i></i>' + safe(value || "Unknown") + "</span>";
  }
  function roleIcon(role) {
    var value = String(role || "").toLowerCase();
    if (value.indexOf("sql") >= 0) { return "◉"; }
    if (value.indexOf("management") >= 0) { return "⇄"; }
    if (value.indexOf("distribution") >= 0) { return "⬡"; }
    return "▣";
  }
  function empty(message) {
    return '<div class="empty-state">' + safe(message) + "</div>";
  }

  function renderMetricCards() {
    var definitions = [
      { key: "osd", label: "OSD SUCCESS", icon: "▣" },
      { key: "patching", label: "PATCH COMPLIANCE", icon: "◉" },
      { key: "software", label: "SOFTWARE SUCCESS", icon: "⬡" },
      { key: "clients", label: "CLIENT HEALTH", icon: "✚" }
    ];
    var html = definitions.map(function (definition) {
      var metric = state.data.metrics[definition.key] || {};
      var rate = Math.max(0, Math.min(100, number(metric.successRate)));
      return [
        '<article class="metric-card ', definition.key, '" data-metric-view="', definition.key, '">',
          '<div class="metric-heading">',
            '<span class="metric-icon ', definition.key, '">', definition.icon, "</span>",
            "<div><small>", definition.label, "</small><strong>", rate.toFixed(1), "%</strong></div>",
          "</div>",
          '<div class="metric-bar"><i style="width:', rate, '%"></i></div>',
          "<footer>",
            '<span class="success">● ', formatNumber(metric.successful), " successful</span>",
            '<span class="failure">● ', formatNumber(metric.failed), " failed</span>",
          "</footer>",
        "</article>"
      ].join("");
    }).join("");
    byId("metric-grid").innerHTML = html;
  }

  function deploymentHtml(rows) {
    if (!rows.length) { return empty("No deployment results are available."); }
    return rows.map(function (deployment) {
      var type = String(deployment.type || "OTHER").toLowerCase();
      var progress = Math.max(0, Math.min(100, number(deployment.progress)));
      return [
        '<div class="deployment-row">',
          "<div>",
            '<span class="deployment-tag ', safe(type), '">', safe(deployment.type || "OTHER"), "</span>",
            "<strong title=\"", safe(deployment.name), '">', safe(deployment.name || "Unnamed deployment"), "</strong>",
            "<em>", progress.toFixed(0), "%</em>",
          "</div>",
          '<div class="progress-track"><i style="width:', progress, '%"></i></div>',
          "<small>",
            '<span class="success">● ', formatNumber(deployment.successful), " successful</span>",
            '<span class="failure">● ', formatNumber(deployment.failed), " failed</span>",
            '<span class="pending">● ', formatNumber(deployment.inProgress), " in progress</span>",
          "</small>",
        "</div>"
      ].join("");
    }).join("");
  }

  function renderOverviewSystems() {
    var priority = { offline: 0, degraded: 1, unknown: 2, online: 3 };
    var rows = array(state.data.infrastructure).slice().sort(function (a, b) {
      return (priority[normalizedStatus(a.status)] || 9) - (priority[normalizedStatus(b.status)] || 9);
    }).slice(0, 6);
    if (!rows.length) {
      byId("overview-systems").innerHTML = empty("No site systems are configured.");
      return;
    }
    byId("overview-systems").innerHTML = rows.map(function (system) {
      var css = normalizedStatus(system.status);
      var response = number(system.responseMs) > 0 ? formatNumber(system.responseMs) + " ms" : "No response";
      return [
        '<div class="system-list-row">',
          '<i class="', css === "online" ? "green" : css === "degraded" ? "amber" : "red", '"></i>',
          "<div><strong>", safe(system.name), "</strong><small>", safe(system.role), " · ", safe(system.siteCode), "</small></div>",
          "<em>", safe(system.status), " · ", response, "</em>",
        "</div>"
      ].join("");
    }).join("");
  }

  function clientRowsHtml(rows) {
    if (!rows.length) {
      return '<tr><td colspan="6" class="empty-state">No client-health rows match the current filter.</td></tr>';
    }
    return rows.map(function (client) {
      return [
        "<tr>",
          "<td>", safe(client.device), "</td>",
          "<td>", safe(client.user || "—"), "</td>",
          "<td>", safe(client.site || "—"), "</td>",
          "<td>", statusPill(client.health), "</td>",
          "<td>", safe(client.lastOnline || "—"), "</td>",
          "<td>", safe(client.issue || "No details"), "</td>",
        "</tr>"
      ].join("");
    }).join("");
  }

  function alertRowsHtml(rows) {
    if (!rows.length) {
      return '<tr><td colspan="6" class="empty-state">No active MECM alerts were returned.</td></tr>';
    }
    return rows.map(function (alert) {
      return [
        "<tr>",
          "<td>", statusPill(alert.severity), "</td>",
          "<td>", safe(alert.name || "MECM alert"), "</td>",
          "<td>", safe(alert.site || "—"), "</td>",
          "<td>", safe(alert.source || "—"), "</td>",
          "<td>", safe(alert.modified || "—"), "</td>",
          "<td>", safe(alert.message || "Review this alert in the MECM console"), "</td>",
        "</tr>"
      ].join("");
    }).join("");
  }

  function distributionRowsHtml(rows) {
    if (!rows.length) {
      return '<tr><td colspan="9" class="empty-state">No per-DP content-distribution rows are available.</td></tr>';
    }
    return rows.map(function (item) {
      return [
        "<tr>",
          "<td>", safe(item.distributionPoint || "—"), "</td>",
          "<td>", safe(item.contentName || "—"), "</td>",
          "<td>", safe(item.packageId || "—"), "</td>",
          "<td>", safe(item.contentType || "Content"), "</td>",
          "<td>", safe(item.site || "—"), "</td>",
          "<td>", statusPill(item.status), "</td>",
          "<td>", safe(item.lastUpdate || "—"), "</td>",
          "<td><code>", safe(item.errorCode || "—"), "</code></td>",
          "<td>", safe(item.errorMessage || "—"), "</td>",
        "</tr>"
      ].join("");
    }).join("");
  }

  function osdErrorRowsHtml(rows) {
    if (!rows.length) {
      return '<tr><td colspan="7" class="empty-state">No failed task-sequence steps were returned.</td></tr>';
    }
    return rows.map(function (item) {
      var deployment = item.deployment || item.advertisementId || item.packageId || "—";
      return [
        "<tr>",
          "<td>", safe(item.device || "—"), "</td>",
          "<td>", safe(deployment), "</td>",
          "<td>", safe(item.step || "—"), "</td>",
          "<td>", safe(item.group || "—"), "</td>",
          "<td><code>", safe(item.errorCode || "—"), "</code></td>",
          "<td>", safe(item.occurred || "—"), "</td>",
          "<td>", safe(item.errorMessage || "—"), "</td>",
        "</tr>"
      ].join("");
    }).join("");
  }

  function clientInstallErrorRowsHtml(rows) {
    if (!rows.length) {
      return '<tr><td colspan="7" class="empty-state">No failed SCCM client installations were returned.</td></tr>';
    }
    return rows.map(function (item) {
      return [
        "<tr>",
          "<td>", safe(item.device || "—"), "</td>",
          "<td>", safe(item.site || "—"), "</td>",
          "<td>", safe(item.clientVersion || "—"), "</td>",
          "<td>", statusPill(item.state || "Failed"), "</td>",
          "<td><code>", safe(item.errorCode || "—"), "</code></td>",
          "<td>", safe(item.lastMessage || "—"), "</td>",
          "<td>", safe(item.details || "—"), "</td>",
        "</tr>"
      ].join("");
    }).join("");
  }

  function renderOverview() {
    var summary = state.data.summary || {};
    var score = Math.max(0, Math.min(100, number(state.data.healthScore)));
    text("health-score", score.toFixed(0));
    byId("health-score-bar").style.width = score + "%";
    text("systems-online", formatNumber(summary.systemsOnline));
    text("systems-online-detail", formatNumber(summary.systemsOnline) + " of " + formatNumber(summary.systemsTotal) + " configured");
    text("active-alerts", formatNumber(summary.activeAlerts));
    text("active-alert-detail", formatNumber(summary.criticalAlerts) + " critical · " + formatNumber(summary.warningAlerts) + " warning");
    if (state.data.dataState === "ConfigurationRequired") {
      text("health-heading", "Add MECM connection details to begin");
      text("health-description", "Enable AdminService, SQL, and server probes in MECMMonitor.xml. No operational values are stored manually.");
    } else if (score >= 90) {
      text("health-heading", "Your MECM environment is healthy");
      text("health-description", "Core services are available. Review the highlighted warnings and failed deployments.");
    } else if (score >= 70) {
      text("health-heading", "Your MECM environment needs attention");
      text("health-description", "One or more infrastructure or component-health checks are degraded.");
    } else {
      text("health-heading", "Critical MECM health conditions detected");
      text("health-description", "Review offline site systems and critical components immediately.");
    }

    renderMetricCards();
    byId("overview-deployments").innerHTML = deploymentHtml(array(state.data.deployments).slice(0, 4));
    renderOverviewSystems();
    var alertRows = array(state.data.alerts);
    text("alert-result-count", formatNumber(alertRows.length) + " active");
    byId("alert-rows").innerHTML = alertRowsHtml(alertRows.slice(0, 25));
    byId("overview-client-rows").innerHTML = clientRowsHtml(array(state.data.clientWatchlist).slice(0, 6));
  }

  function renderSystems() {
    var summary = state.data.summary || {};
    text("systems-banner-heading", formatNumber(summary.systemsOnline) + " of " + formatNumber(summary.systemsTotal) + " systems online");
    text("systems-banner-copy", formatNumber(summary.systemsOffline) + " offline and " + formatNumber(summary.systemsDegraded) + " degraded across the configured infrastructure.");
    byId("systems-summary").innerHTML = [
      '<span><i style="background:var(--green)"></i><b>', formatNumber(summary.systemsOnline), "</b><small>Online</small></span>",
      '<span><i style="background:var(--amber)"></i><b>', formatNumber(summary.systemsDegraded), "</b><small>Degraded</small></span>",
      '<span><i style="background:var(--red)"></i><b>', formatNumber(summary.systemsOffline), "</b><small>Offline</small></span>"
    ].join("");

    var roleFilter = byId("role-filter");
    var currentRole = roleFilter.value;
    var roles = array(state.data.infrastructure).map(function (item) { return item.role; })
      .filter(function (value, index, all) { return value && all.indexOf(value) === index; })
      .sort();
    roleFilter.innerHTML = '<option value="">All roles</option>' + roles.map(function (role) {
      return '<option value="' + safe(role) + '">' + safe(role) + "</option>";
    }).join("");
    roleFilter.value = roles.indexOf(currentRole) >= 0 ? currentRole : "";
    renderSystemCards();

    var componentRows = array(state.data.components);
    byId("component-rows").innerHTML = componentRows.length ? componentRows.map(function (component) {
      return [
        "<tr>",
          "<td>", safe(component.name), "</td>",
          "<td>", safe(component.server), "</td>",
          "<td>", safe(component.state || "—"), "</td>",
          "<td>", statusPill(component.status), "</td>",
          "<td>", safe(component.lastMessage || "—"), "</td>",
          "<td>", safe(component.message || "No details"), "</td>",
        "</tr>"
      ].join("");
    }).join("") : '<tr><td colspan="6" class="empty-state">No component status is available.</td></tr>';

    var diagnostics = array(state.data.diagnostics);
    byId("diagnostic-list").innerHTML = diagnostics.length ? diagnostics.map(function (item) {
      var mapped = String(item.status || "").toLowerCase() === "error" ? "Critical" :
        String(item.status || "").toLowerCase() === "warning" ? "Warning" : "Healthy";
      return [
        '<div class="diagnostic-row">',
          statusPill(mapped),
          "<strong>", safe(item.source), "</strong>",
          "<span>", safe(item.message), "</span>",
        "</div>"
      ].join("");
    }).join("") : empty("No diagnostics were reported.");
  }

  function renderSystemCards() {
    var filter = byId("role-filter").value;
    var systems = array(state.data.infrastructure).filter(function (system) {
      return !filter || system.role === filter;
    });
    byId("system-card-grid").innerHTML = systems.length ? systems.map(function (system) {
      var css = normalizedStatus(system.status);
      var response = number(system.responseMs) > 0 ? formatNumber(system.responseMs) + " ms" : "No response";
      var free = system.percentFree === null || system.percentFree === undefined ? safe(system.uptime || "—") : formatNumber(system.percentFree) + "% free";
      return [
        '<article class="system-card ', css, '">',
          '<div class="system-card-header">',
            '<span class="system-card-icon">', roleIcon(system.role), "</span>",
            '<div class="system-card-title"><small>', safe(String(system.role || "").toUpperCase()), "</small><h3>", safe(system.name), "</h3><p>", safe(system.siteCode), " Site · TCP ", formatNumber(system.port), "</p></div>",
            statusPill(system.status),
          "</div>",
          '<div class="system-card-stats">',
            "<span><small>RESPONSE</small><b>", response, "</b></span>",
            "<span><small>UPTIME / CAPACITY</small><b>", free, "</b></span>",
          "</div>",
          "<footer>", safe(system.note || "No status message"), "</footer>",
        "</article>"
      ].join("");
    }).join("") : empty("No systems match this role.");
  }

  function renderWorkload() {
    var config = workloadConfig[state.workload];
    var metric = state.data.metrics[config.key] || {};
    var rate = number(metric.successRate);
    text("workload-eyebrow", config.eyebrow);
    text("workload-heading", config.heading);
    text("workload-copy", config.copy);
    text("workload-rate", rate.toFixed(1) + "%");
    text("workload-list-title", config.listTitle);
    byId("workload-stats").innerHTML = [
      '<article class="workload-stat"><span>SUCCESSFUL</span><strong class="success">', formatNumber(metric.successful), "</strong></article>",
      '<article class="workload-stat"><span>FAILED</span><strong class="failure">', formatNumber(metric.failed), "</strong></article>",
      '<article class="workload-stat"><span>IN PROGRESS</span><strong class="pending">', formatNumber(metric.inProgress), "</strong></article>",
      '<article class="workload-stat"><span>UNKNOWN</span><strong>', formatNumber(metric.unknown), "</strong></article>"
    ].join("");
    var rows = array(state.data.deployments).filter(function (deployment) {
      return config.type.indexOf(String(deployment.type || "").toUpperCase()) >= 0;
    });
    byId("workload-deployments").innerHTML = deploymentHtml(rows);

    var showOsdErrors = state.workload === "osd";
    var osdRows = array(state.data.osdErrors);
    byId("osd-error-panel").classList.toggle("hidden", !showOsdErrors);
    if (showOsdErrors) {
      text("osd-error-count", formatNumber(osdRows.length) + " failures");
      byId("osd-error-rows").innerHTML = osdErrorRowsHtml(osdRows.slice(0, 250));
    }

    var showDistribution = state.workload === "software";
    var distributionRows = array(state.data.distributionStatus);
    byId("distribution-panel").classList.toggle("hidden", !showDistribution);
    if (showDistribution) {
      var failedCount = distributionRows.filter(function (item) {
        return normalizedStatus(item.status) === "critical";
      }).length;
      text("distribution-count", formatNumber(failedCount) + " failed · " +
        formatNumber(distributionRows.length) + " total");
      byId("distribution-rows").innerHTML = distributionRowsHtml(distributionRows.slice(0, 250));
    }
  }

  function renderClients() {
    var metric = state.data.metrics.clients || {};
    text("client-rate", number(metric.successRate).toFixed(1) + "%");
    byId("client-stats").innerHTML = [
      '<article class="workload-stat"><span>HEALTHY</span><strong class="success">', formatNumber(metric.successful), "</strong></article>",
      '<article class="workload-stat"><span>CRITICAL</span><strong class="failure">', formatNumber(metric.failed), "</strong></article>",
      '<article class="workload-stat"><span>NEEDS ATTENTION</span><strong class="pending">', formatNumber(metric.inProgress), "</strong></article>",
      '<article class="workload-stat"><span>UNKNOWN</span><strong>', formatNumber(metric.unknown), "</strong></article>"
    ].join("");
    var siteFilter = byId("client-site-filter");
    var selectedSite = siteFilter.value;
    var sites = array(state.data.clientWatchlist).map(function (client) { return client.site; })
      .filter(function (value, index, all) { return value && all.indexOf(value) === index; })
      .sort();
    siteFilter.innerHTML = '<option value="">All sites</option>' + sites.map(function (site) {
      return '<option value="' + safe(site) + '">' + safe(site) + "</option>";
    }).join("");
    siteFilter.value = sites.indexOf(selectedSite) >= 0 ? selectedSite : "";
    renderClientFilter();

    var installErrors = array(state.data.clientInstallErrors);
    text("client-install-error-count", formatNumber(installErrors.length) + " failures");
    byId("client-install-error-rows").innerHTML =
      clientInstallErrorRowsHtml(installErrors.slice(0, 250));
  }

  function renderClientFilter() {
    if (!state.data) { return; }
    var query = String(byId("client-search").value || "").toLowerCase();
    var health = byId("client-health-filter").value;
    var site = byId("client-site-filter").value;
    var rows = array(state.data.clientWatchlist).filter(function (client) {
      var textValue = [client.device, client.user, client.site, client.issue].join(" ").toLowerCase();
      return (!query || textValue.indexOf(query) >= 0) &&
        (!health || client.health === health) &&
        (!site || client.site === site);
    });
    var pageSize = Math.max(25, number(state.data.clientPageSize || 100));
    var pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
    state.clientPage = Math.max(1, Math.min(state.clientPage, pageCount));
    var start = (state.clientPage - 1) * pageSize;
    byId("client-rows").innerHTML = clientRowsHtml(rows.slice(start, start + pageSize));
    text("client-result-count", formatNumber(rows.length) + " of " + formatNumber(array(state.data.clientWatchlist).length) + " clients");
    text("client-page", "Page " + state.clientPage + " of " + pageCount);
    byId("client-prev").disabled = state.clientPage <= 1;
    byId("client-next").disabled = state.clientPage >= pageCount;
  }

  function deploymentRows(types) {
    return array(state.data.deployments).filter(function (deployment) {
      return types.indexOf(String(deployment.type || "").toUpperCase()) >= 0;
    });
  }

  function overviewExportRows() {
    var rows = [];
    var summary = state.data.summary || {};
    Object.keys(summary).forEach(function (key) {
      rows.push({ section: "Summary", metric: key, value: summary[key] });
    });
    Object.keys(state.data.metrics || {}).forEach(function (key) {
      var metric = state.data.metrics[key] || {};
      Object.keys(metric).forEach(function (name) {
        rows.push({ section: key, metric: name, value: metric[name] });
      });
    });
    rows.push({ section: "Snapshot", metric: "generatedAtUtc", value: state.data.generatedAtUtc });
    rows.push({ section: "Snapshot", metric: "siteCode", value: state.data.siteCode });
    rows.push({ section: "Snapshot", metric: "dataState", value: state.data.dataState });
    rows.push({ section: "Snapshot", metric: "healthScore", value: state.data.healthScore });
    return rows;
  }

  function taggedRows(label, rows) {
    return array(rows).map(function (row) {
      var tagged = { recordType: label };
      Object.keys(row || {}).forEach(function (key) { tagged[key] = row[key]; });
      return tagged;
    });
  }

  function currentExportRows() {
    if (state.activeView === "osd") {
      return taggedRows("OSD deployment", deploymentRows(["OSD"]))
        .concat(taggedRows("OSD step failure", state.data.osdErrors));
    }
    if (state.activeView === "patching") {
      return taggedRows("Patch deployment", deploymentRows(["PATCH"]));
    }
    if (state.activeView === "software") {
      return taggedRows("Software deployment", deploymentRows(["APP", "PACKAGE", "DISTRIBUTION"]))
        .concat(taggedRows("DP content distribution", state.data.distributionStatus));
    }
    if (state.activeView === "clients") {
      return taggedRows("Client health", state.data.clientWatchlist)
        .concat(taggedRows("Client installation failure", state.data.clientInstallErrors));
    }
    if (state.activeView === "systems") {
      return taggedRows("Site system", state.data.infrastructure)
        .concat(taggedRows("Component health", state.data.components))
        .concat(taggedRows("Collector diagnostic", state.data.diagnostics));
    }
    return overviewExportRows();
  }

  function allExportRows() {
    return taggedRows("Overview", overviewExportRows())
      .concat(taggedRows("OSD deployment", deploymentRows(["OSD"])))
      .concat(taggedRows("Patch deployment", deploymentRows(["PATCH"])))
      .concat(taggedRows("Software deployment", deploymentRows(["APP", "PACKAGE", "DISTRIBUTION"])))
      .concat(taggedRows("DP content distribution", state.data.distributionStatus))
      .concat(taggedRows("OSD step failure", state.data.osdErrors))
      .concat(taggedRows("Client health", state.data.clientWatchlist))
      .concat(taggedRows("Client installation failure", state.data.clientInstallErrors))
      .concat(taggedRows("Active alert", state.data.alerts))
      .concat(taggedRows("Site system", state.data.infrastructure))
      .concat(taggedRows("Component health", state.data.components))
      .concat(taggedRows("Collector diagnostic", state.data.diagnostics));
  }

  function getExportRows(dataset) {
    var maps = {
      overview: function () { return overviewExportRows(); },
      osdDeployments: function () { return deploymentRows(["OSD"]); },
      patchDeployments: function () { return deploymentRows(["PATCH"]); },
      softwareDeployments: function () { return deploymentRows(["APP", "PACKAGE", "DISTRIBUTION"]); },
      distributionStatus: function () { return array(state.data.distributionStatus); },
      osdErrors: function () { return array(state.data.osdErrors); },
      clientWatchlist: function () { return array(state.data.clientWatchlist); },
      clientInstallErrors: function () { return array(state.data.clientInstallErrors); },
      alerts: function () { return array(state.data.alerts); },
      infrastructure: function () { return array(state.data.infrastructure); },
      components: function () { return array(state.data.components); },
      diagnostics: function () { return array(state.data.diagnostics); },
      all: function () { return allExportRows(); },
      current: function () { return currentExportRows(); }
    };
    return maps[dataset] ? maps[dataset]() : [];
  }

  function csvValue(value) {
    var textValue = value === null || value === undefined ? "" : String(value);
    if (/^[=+\-@]/.test(textValue)) { textValue = "'" + textValue; }
    return '"' + textValue.replace(/"/g, '""') + '"';
  }

  function exportCsv() {
    if (!state.data) { return; }
    var dataset = byId("export-dataset").value;
    var rows = getExportRows(dataset);
    if (!rows.length) {
      window.alert("No rows are available for this CSV export.");
      return;
    }
    var headers = [];
    rows.forEach(function (row) {
      Object.keys(row || {}).forEach(function (key) {
        if (headers.indexOf(key) < 0) { headers.push(key); }
      });
    });
    var lines = [headers.map(csvValue).join(",")];
    rows.forEach(function (row) {
      lines.push(headers.map(function (key) { return csvValue(row[key]); }).join(","));
    });

    var stamp = new Date().toISOString().replace(/[:.]/g, "-");
    var site = String(state.data.siteCode || "MECM").replace(/[^A-Za-z0-9_-]/g, "");
    var filename = site + "-" + dataset + "-" + stamp + ".csv";
    var blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function updateClock() {
    text("live-clock", new Date().toLocaleTimeString());
  }

  function updateFreshness() {
    if (!state.data) { return; }
    var generated = new Date(state.data.generatedAtUtc);
    var ageMinutes = (Date.now() - generated.getTime()) / 60000;
    var stale = !Number.isFinite(ageMinutes) || ageMinutes > number(state.data.staleAfterMinutes || 10);
    var indicator = document.querySelector(".live-indicator");
    indicator.classList.toggle("stale", stale);
    text("freshness-label", stale ? "STALE" : "LIVE");
    text("last-updated", Number.isNaN(generated.getTime()) ? "Snapshot unknown" : "Snapshot " + generated.toLocaleTimeString());
    text("sidebar-state", stale ? "Snapshot is stale" : "Collector connected");
    byId("sidebar-dot").style.background = stale ? "var(--amber)" : "var(--green)";
  }

  function renderAll() {
    var data = state.data;
    document.title = data.title || "MECM Command Center";
    text("page-title", state.activeView === "overview" ? data.title : currentViewTitle());
    text("sidebar-site", data.siteCode || "---");
    text("mode-name", data.mode || "Automatic");
    text("system-alert-count", formatNumber(
      number((data.summary || {}).systemsOffline) +
      number((data.summary || {}).systemsDegraded) +
      number((data.summary || {}).activeAlerts)
    ));
    text("snapshot-time", "Updated " + new Date(data.generatedAtUtc).toLocaleString());
    renderOverview();
    renderSystems();
    renderWorkload();
    renderClients();
    updateFreshness();
  }

  function currentViewTitle() {
    if (state.activeView === "systems") { return "Site Systems"; }
    if (state.activeView === "clients") { return "Client Health"; }
    if (workloadConfig[state.activeView]) { return workloadConfig[state.activeView].title; }
    return state.data ? state.data.title : "MECM Command Center";
  }

  function navigate(view) {
    state.activeView = view;
    if (workloadConfig[view]) { state.workload = view; }
    document.querySelectorAll(".nav-button").forEach(function (button) {
      button.classList.toggle("active", button.getAttribute("data-view") === view);
    });
    document.querySelectorAll(".view-panel").forEach(function (panel) {
      var panelType = panel.getAttribute("data-view-panel");
      var show = panelType === view || (panelType === "workload" && workloadConfig[view]);
      panel.classList.toggle("hidden", !show);
    });
    text("breadcrumb", "OPERATIONS / " + currentViewTitle().toUpperCase());
    text("page-title", currentViewTitle());
    var subtitle = view === "systems" ? "Live health of site servers and MECM infrastructure roles." :
      view === "clients" ? "Client evaluation, communication and remediation status." :
      workloadConfig[view] ? workloadConfig[view].copy :
      "Current operational health across the managed estate.";
    text("page-subtitle", subtitle);
    if (state.data && workloadConfig[view]) { renderWorkload(); }
    window.scrollTo(0, 0);
  }

  function showFetchError(message) {
    var alert = byId("connection-alert");
    alert.textContent = "Dashboard data could not be refreshed: " + message + ". The last successful snapshot remains displayed.";
    alert.classList.remove("hidden");
  }

  function configureTimer() {
    if (state.timer) { window.clearInterval(state.timer); }
    var seconds = state.data ? Math.max(10, number(state.data.refreshSeconds || 15)) : 15;
    state.timer = window.setInterval(fetchData, seconds * 1000);
  }

  function fetchData() {
    var button = byId("refresh-button");
    button.classList.add("refreshing");
    fetch("data/dashboard.json?t=" + Date.now(), { cache: "no-store", credentials: "same-origin" })
      .then(function (response) {
        if (!response.ok) { throw new Error("HTTP " + response.status); }
        return response.json();
      })
      .then(function (data) {
        if (number(data.schemaVersion) !== 1) { throw new Error("Unsupported dashboard schema"); }
        state.data = data;
        byId("connection-alert").classList.add("hidden");
        renderAll();
        configureTimer();
      })
      .catch(function (error) {
        showFetchError(error.message || "Unknown error");
      })
      .finally(function () {
        button.classList.remove("refreshing");
      });
  }

  document.querySelectorAll(".nav-button").forEach(function (button) {
    button.addEventListener("click", function () { navigate(button.getAttribute("data-view")); });
  });
  document.querySelectorAll("[data-go-view]").forEach(function (button) {
    button.addEventListener("click", function () { navigate(button.getAttribute("data-go-view")); });
  });
  byId("refresh-button").addEventListener("click", fetchData);
  byId("export-button").addEventListener("click", exportCsv);
  byId("role-filter").addEventListener("change", renderSystemCards);
  byId("client-search").addEventListener("input", function () {
    state.clientPage = 1;
    renderClientFilter();
  });
  byId("client-health-filter").addEventListener("change", function () {
    state.clientPage = 1;
    renderClientFilter();
  });
  byId("client-site-filter").addEventListener("change", function () {
    state.clientPage = 1;
    renderClientFilter();
  });
  byId("client-prev").addEventListener("click", function () {
    state.clientPage = Math.max(1, state.clientPage - 1);
    renderClientFilter();
  });
  byId("client-next").addEventListener("click", function () {
    state.clientPage += 1;
    renderClientFilter();
  });

  updateClock();
  state.clockTimer = window.setInterval(updateClock, 1000);
  fetchData();
})();
