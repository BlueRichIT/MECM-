[CmdletBinding()]
param(
    [Parameter()]
    [string]$ConfigPath = (Join-Path (Split-Path $PSScriptRoot -Parent) "Config\MECMMonitor.xml"),

    [Parameter()]
    [string]$OutputPath = (Join-Path (Split-Path $PSScriptRoot -Parent) "wwwroot\data\dashboard.json"),

    [Parameter()]
    [string]$LogPath = (Join-Path (Split-Path $PSScriptRoot -Parent) "Logs\collector.log")
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$script:Diagnostics = New-Object System.Collections.Generic.List[object]

function Write-CollectorLog {
    param([string]$Level, [string]$Message)

    $directory = Split-Path -Parent $LogPath
    if (-not [string]::IsNullOrWhiteSpace($directory) -and -not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
    $line = "{0:u} [{1}] {2}" -f (Get-Date), $Level.ToUpperInvariant(), $Message
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}

function Add-Diagnostic {
    param([string]$Source, [string]$Status, [string]$Message)

    $script:Diagnostics.Add([pscustomobject][ordered]@{
        source = $Source
        status = $Status
        message = $Message
    })
    Write-CollectorLog -Level $Status -Message ("{0}: {1}" -f $Source, $Message)
}

function Get-XmlValue {
    param($Node, [string]$Name, $Default = "")

    if ($null -eq $Node) { return $Default }
    $attribute = $Node.Attributes[$Name]
    if ($null -ne $attribute) { return $attribute.Value }
    $property = $Node.PSObject.Properties[$Name]
    if ($null -ne $property -and $null -ne $property.Value) { return $property.Value }
    return $Default
}

function Convert-ToBoolean {
    param($Value, [bool]$Default = $false)

    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return $Default }
    $parsed = $false
    if ([bool]::TryParse([string]$Value, [ref]$parsed)) { return $parsed }
    return $Default
}

function Convert-ToInt {
    param($Value, [int]$Default = 0)

    $parsed = 0
    if ($null -ne $Value -and [int]::TryParse([string]$Value, [ref]$parsed)) { return $parsed }
    return $Default
}

function Convert-ToDouble {
    param($Value, [double]$Default = 0)

    $parsed = 0.0
    if ($null -ne $Value -and [double]::TryParse(
        [string]$Value,
        [System.Globalization.NumberStyles]::Any,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [ref]$parsed
    )) {
        return $parsed
    }
    return $Default
}

function Get-ObjectValue {
    param($Object, [string[]]$Names, $Default = $null)

    if ($null -eq $Object) { return $Default }
    foreach ($name in $Names) {
        $value = $null
        $found = $false
        if ($Object -is [System.Data.DataRow]) {
            if ($Object.Table.Columns.Contains($name)) {
                $value = $Object[$name]
                $found = $true
            }
        }
        else {
            $property = $Object.PSObject.Properties[$name]
            if ($null -ne $property) {
                $value = $property.Value
                $found = $true
            }
        }
        if ($found -and $null -ne $value -and $value -ne [DBNull]::Value) {
            return $value
        }
    }
    return $Default
}

function Normalize-ServerName {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    $normalized = $Name.Trim().TrimStart("\")
    if ($normalized.Contains("\")) { $normalized = $normalized.Split("\")[0] }
    if ($normalized.Contains(".")) { $normalized = $normalized.Split(".")[0] }
    return $normalized.ToUpperInvariant()
}

function Convert-MecmHealthStatus {
    param([int]$Status)

    switch ($Status) {
        0 { return "Healthy" }
        1 { return "Warning" }
        2 { return "Critical" }
        default { return "Unknown" }
    }
}

function Convert-DateForDisplay {
    param($Value, [string]$Default = "")

    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return $Default }
    $parsed = [DateTime]::MinValue
    if ([DateTime]::TryParse([string]$Value, [ref]$parsed)) {
        return $parsed.ToString("yyyy-MM-dd HH:mm")
    }
    return [string]$Value
}

function Format-ErrorCode {
    param($Value)

    if ($null -eq $Value -or $Value -eq [DBNull]::Value -or
        [string]::IsNullOrWhiteSpace([string]$Value)) {
        return ""
    }
    $text = ([string]$Value).Trim()
    if ($text -match "^0x[0-9A-Fa-f]+$") { return $text.ToUpperInvariant() }

    $number = [int64]0
    if ([int64]::TryParse(
        $text,
        [System.Globalization.NumberStyles]::Integer,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [ref]$number
    )) {
        if ($number -ge [int32]::MinValue -and $number -le [int32]::MaxValue) {
            $bytes = [BitConverter]::GetBytes([int32]$number)
            $unsigned = [BitConverter]::ToUInt32($bytes, 0)
            return "{0} (0x{1})" -f $number, $unsigned.ToString("X8")
        }
        return "{0} (0x{1})" -f $number, $number.ToString("X")
    }
    return $text
}

function Get-DistributionPointName {
    param($Row)

    $direct = [string](Get-ObjectValue $Row @(
        "ServerName", "DPName", "DistributionPoint", "NALServerName", "MachineName"
    ) "")
    if (-not [string]::IsNullOrWhiteSpace($direct)) {
        return Normalize-ServerName $direct
    }

    $path = [string](Get-ObjectValue $Row @(
        "DPNALPath", "DPNalPath", "NALPath", "ServerNALPath", "ServerPath"
    ) "")
    if ($path -match "\\\\([^\\\]\s]+)") {
        return Normalize-ServerName $matches[1]
    }
    return Normalize-ServerName $path
}

function Get-ContentStatusName {
    param($Row)

    $text = [string](Get-ObjectValue $Row @(
        "StateName", "StatusName", "DistributionStatus", "Status"
    ) "")
    if (-not [string]::IsNullOrWhiteSpace($text) -and $text -notmatch "^-?\d+$") {
        return $text
    }

    $state = Convert-ToInt (Get-ObjectValue $Row @("State", "MessageState", "Status") "-1") -1
    switch ($state) {
        0 { return "Installed" }
        1 { return "In progress" }
        2 { return "Retrying" }
        3 { return "Failed" }
        4 { return "Removal pending" }
        5 { return "Removal retrying" }
        6 { return "Removal failed" }
        7 { return "Removed" }
        default { return "Unknown" }
    }
}

function Get-ContentTypeName {
    param($Row)

    $text = [string](Get-ObjectValue $Row @(
        "ContentTypeName", "PackageTypeName", "ObjectTypeName", "FeatureTypeName"
    ) "")
    if (-not [string]::IsNullOrWhiteSpace($text)) { return $text }

    $type = Get-ObjectValue $Row @("PackageType", "ContentType", "ObjectType", "FeatureType") $null
    if ($null -eq $type -or [string]::IsNullOrWhiteSpace([string]$type)) { return "Content" }
    switch (Convert-ToInt $type -1) {
        0 { return "Package" }
        3 { return "Driver package" }
        4 { return "Task sequence" }
        5 { return "Software update package" }
        7 { return "Application content" }
        8 { return "Boot image" }
        257 { return "Operating system image" }
        258 { return "Boot image" }
        259 { return "Operating system installer" }
        default { return "Content type {0}" -f [string]$type }
    }
}

function Get-LatestLookupRow {
    param([hashtable]$Lookup, [string]$Key, $Row, [string[]]$DateNames)

    if ([string]::IsNullOrWhiteSpace($Key)) { return }
    if (-not $Lookup.ContainsKey($Key)) {
        $Lookup[$Key] = $Row
        return
    }
    $existingDate = [DateTime]::MinValue
    $candidateDate = [DateTime]::MinValue
    [void][DateTime]::TryParse(
        [string](Get-ObjectValue $Lookup[$Key] $DateNames ""),
        [ref]$existingDate
    )
    [void][DateTime]::TryParse(
        [string](Get-ObjectValue $Row $DateNames ""),
        [ref]$candidateDate
    )
    if ($candidateDate -gt $existingDate) { $Lookup[$Key] = $Row }
}

function Test-TcpEndpoint {
    param(
        [string]$ComputerName,
        [int]$Port,
        [int]$TimeoutMilliseconds = 3000
    )

    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($ComputerName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMilliseconds, $false)) {
            throw "Connection timed out"
        }
        $client.EndConnect($async)
        $watch.Stop()
        return [pscustomobject][ordered]@{
            reachable = $true
            responseMs = [math]::Max(1, [int]$watch.ElapsedMilliseconds)
            error = ""
        }
    }
    catch {
        $watch.Stop()
        return [pscustomobject][ordered]@{
            reachable = $false
            responseMs = 0
            error = $_.Exception.Message
        }
    }
    finally {
        $client.Close()
    }
}

function Invoke-AdminServiceQuery {
    param(
        [string]$BaseUri,
        [string]$RelativePath,
        [int]$TimeoutSeconds
    )

    $uri = "{0}/{1}" -f $BaseUri.TrimEnd("/"), $RelativePath.TrimStart("/")
    $results = New-Object System.Collections.Generic.List[object]
    $page = 0
    while (-not [string]::IsNullOrWhiteSpace($uri) -and $page -lt 25) {
        $response = Invoke-RestMethod -Method Get -Uri $uri -UseDefaultCredentials `
            -TimeoutSec $TimeoutSeconds -Headers @{ Accept = "application/json" }
        $items = if ($null -ne $response.PSObject.Properties["value"]) { @($response.value) } else { @($response) }
        foreach ($item in $items) { $results.Add($item) }
        $next = Get-ObjectValue -Object $response -Names @("@odata.nextLink", "odata.nextLink") -Default ""
        if ([string]::IsNullOrWhiteSpace([string]$next)) {
            $uri = ""
        }
        elseif ([string]$next -match "^https?://") {
            $uri = [string]$next
        }
        elseif ([string]$next -match "^/") {
            $base = [uri]$BaseUri
            $uri = "{0}://{1}{2}" -f $base.Scheme, $base.Authority, [string]$next
        }
        else {
            $uri = "{0}/{1}" -f $BaseUri.TrimEnd("/"), ([string]$next).TrimStart("/")
        }
        $page++
    }
    return $results.ToArray()
}

function New-SqlConnectionString {
    param($SqlConfig)

    $server = [string](Get-XmlValue $SqlConfig "Server")
    $instance = [string](Get-XmlValue $SqlConfig "Instance")
    $port = Convert-ToInt (Get-XmlValue $SqlConfig "Port" "1433") 1433
    $database = [string](Get-XmlValue $SqlConfig "Database")
    if ([string]::IsNullOrWhiteSpace($server) -or [string]::IsNullOrWhiteSpace($database)) {
        throw "SQL Server and Database are required when SQL collection is enabled."
    }

    $dataSource = if ([string]::IsNullOrWhiteSpace($instance)) { $server } else { "{0}\{1}" -f $server, $instance }
    if ($port -gt 0) { $dataSource = "{0},{1}" -f $dataSource, $port }
    $builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $builder.DataSource = $dataSource
    $builder.InitialCatalog = $database
    $builder.IntegratedSecurity = $true
    $builder.ApplicationName = "MECM Health Monitor"
    $builder.ConnectTimeout = 30
    $builder.Encrypt = Convert-ToBoolean (Get-XmlValue $SqlConfig "Encrypt" "true") $true
    $builder.TrustServerCertificate = Convert-ToBoolean (Get-XmlValue $SqlConfig "TrustServerCertificate" "false") $false
    return $builder.ConnectionString
}

function Invoke-SqlTable {
    param(
        [string]$ConnectionString,
        [string]$Query,
        [int]$CommandTimeoutSeconds
    )

    $connection = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $CommandTimeoutSeconds
    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($command)
    $table = New-Object System.Data.DataTable
    try {
        $connection.Open()
        [void]$adapter.Fill($table)
        return $table
    }
    finally {
        $adapter.Dispose()
        $command.Dispose()
        $connection.Dispose()
    }
}

function Get-TableRows {
    param([System.Data.DataTable]$Table)

    if ($null -eq $Table) { return @() }
    return @($Table.Rows | ForEach-Object { $_ })
}

function Add-LookupRow {
    param([hashtable]$Lookup, [string]$Key, $Row)

    if ([string]::IsNullOrWhiteSpace($Key)) { return }
    if (-not $Lookup.ContainsKey($Key)) {
        $Lookup[$Key] = New-Object System.Collections.ArrayList
    }
    [void]$Lookup[$Key].Add($Row)
}

function Get-ClientHealthFromText {
    param([string]$Text)

    $value = $Text.ToLowerInvariant()
    if ($value -match "critical|error|failed|failure|unhealthy|inactive") { return "Critical" }
    if ($value -match "warning|remediat|attention|pending") { return "Warning" }
    if ($value -match "healthy|success|passed|active|compliant|online") { return "Healthy" }
    return "Unknown"
}

function Get-EvaluationIssue {
    param($Row)

    $description = [string](Get-ObjectValue $Row @(
        "HealthCheckName", "Description", "EvaluationDescription", "ResultDescription", "CheckName"
    ) "")
    $resultText = [string](Get-ObjectValue $Row @(
        "ResultName", "EvaluationResultName", "StateName", "ResultDescription"
    ) "")
    $resultCodeValue = Get-ObjectValue $Row @("ResultCode", "ErrorCode") $null
    $isFailure = $false
    if (-not [string]::IsNullOrWhiteSpace($resultText) -and
        $resultText -match "(?i)error|fail|critical|unhealthy|remediation failed") {
        $isFailure = $true
    }
    elseif ($null -ne $resultCodeValue) {
        $resultCode = 0
        if ([int]::TryParse([string]$resultCodeValue, [ref]$resultCode) -and $resultCode -ne 0) {
            $isFailure = $true
        }
    }
    if (-not $isFailure) { return "" }

    $checkId = [string](Get-ObjectValue $Row @("HealthCheckID", "CheckID", "EvaluationID") "")
    if (-not [string]::IsNullOrWhiteSpace($description)) { return $description }
    if (-not [string]::IsNullOrWhiteSpace($resultText)) { return $resultText }
    if (-not [string]::IsNullOrWhiteSpace($checkId)) { return "Client health check $checkId failed" }
    return "Client health evaluation failed"
}

function Get-SqlClients {
    param(
        [string]$ConnectionString,
        [int]$CommandTimeoutSeconds,
        [int]$MaxClients,
        [string[]]$AvailableViews
    )

    if ($AvailableViews -notcontains "v_R_System") {
        throw "Required reporting view v_R_System was not found."
    }

    $topClause = if ($MaxClients -gt 0) { "TOP ($MaxClients) " } else { "" }
    $resourceQuery = @"
SELECT ${topClause}ResourceID, Name0, User_Name0, Site_Code0, Active0
FROM dbo.v_R_System
WHERE Client0 = 1 AND ISNULL(Obsolete0, 0) = 0
ORDER BY Name0
"@
    $resources = Get-TableRows (Invoke-SqlTable $ConnectionString $resourceQuery $CommandTimeoutSeconds)
    $summaryRows = @()
    $evaluationRows = @()
    $stateRows = @()
    if ($AvailableViews -contains "v_CH_ClientSummary") {
        $summaryRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT * FROM dbo.v_CH_ClientSummary" $CommandTimeoutSeconds)
    }
    if ($AvailableViews -contains "v_CH_EvalResults") {
        $evaluationRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT * FROM dbo.v_CH_EvalResults" $CommandTimeoutSeconds)
    }
    if ($AvailableViews -contains "v_StateNames") {
        $stateRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT TopicType, StateID, StateName FROM dbo.v_StateNames WHERE TopicType BETWEEN 1000 AND 1004" $CommandTimeoutSeconds)
    }

    $summaryLookup = @{}
    foreach ($row in $summaryRows) {
        Add-LookupRow $summaryLookup ([string](Get-ObjectValue $row @("ResourceID") "")) $row
    }
    $evaluationLookup = @{}
    foreach ($row in $evaluationRows) {
        Add-LookupRow $evaluationLookup ([string](Get-ObjectValue $row @("ResourceID") "")) $row
    }
    $stateLookup = @{}
    foreach ($row in $stateRows) {
        $key = "{0}|{1}" -f (Get-ObjectValue $row @("TopicType", "StateType") ""), (Get-ObjectValue $row @("StateID") "")
        $stateLookup[$key] = [string](Get-ObjectValue $row @("StateName") "")
    }

    $clients = New-Object System.Collections.Generic.List[object]
    foreach ($resource in $resources) {
        $resourceId = [string](Get-ObjectValue $resource @("ResourceID") "")
        $summaries = if ($summaryLookup.ContainsKey($resourceId)) { @($summaryLookup[$resourceId]) } else { @() }
        $evaluations = if ($evaluationLookup.ContainsKey($resourceId)) { @($evaluationLookup[$resourceId]) } else { @() }
        $healthCandidates = New-Object System.Collections.Generic.List[string]
        $issues = New-Object System.Collections.Generic.List[string]
        $lastOnlineValues = New-Object System.Collections.Generic.List[DateTime]

        foreach ($summary in $summaries) {
            $stateName = [string](Get-ObjectValue $summary @("HealthStateName", "StateName", "HealthStatusName") "")
            if ([string]::IsNullOrWhiteSpace($stateName)) {
                $stateKey = "{0}|{1}" -f (Get-ObjectValue $summary @("HealthType", "TopicType") ""), (Get-ObjectValue $summary @("HealthState", "StateID") "")
                if ($stateLookup.ContainsKey($stateKey)) { $stateName = $stateLookup[$stateKey] }
            }
            if (-not [string]::IsNullOrWhiteSpace($stateName)) {
                $healthCandidates.Add((Get-ClientHealthFromText $stateName))
                if ((Get-ClientHealthFromText $stateName) -in @("Critical", "Warning")) {
                    $issues.Add($stateName)
                }
            }
            $lastOnlineRaw = Get-ObjectValue $summary @(
                "LastOnline", "LastActiveTime", "LastStatusMessage", "LastHealthEvaluation", "LastPolicyRequest"
            ) $null
            $lastOnline = [DateTime]::MinValue
            if ($null -ne $lastOnlineRaw -and [DateTime]::TryParse([string]$lastOnlineRaw, [ref]$lastOnline)) {
                $lastOnlineValues.Add($lastOnline)
            }
        }

        foreach ($evaluation in $evaluations) {
            $evaluationIssue = Get-EvaluationIssue $evaluation
            if (-not [string]::IsNullOrWhiteSpace($evaluationIssue)) { $issues.Add($evaluationIssue) }
        }

        $active = Convert-ToInt (Get-ObjectValue $resource @("Active0") "0") 0
        $health = if ($active -eq 0) {
            $issues.Insert(0, "Client is marked inactive in MECM")
            "Critical"
        }
        elseif ($issues.Count -gt 0 -or $healthCandidates -contains "Critical") {
            "Critical"
        }
        elseif ($healthCandidates -contains "Warning") {
            "Warning"
        }
        elseif ($healthCandidates -contains "Healthy") {
            "Healthy"
        }
        elseif ($summaries.Count -eq 0) {
            $issues.Add("No client-health summary was returned")
            "Unknown"
        }
        else {
            "Unknown"
        }

        if ($health -eq "Healthy" -and $issues.Count -eq 0) { $issues.Add("All reported checks passed") }
        $lastOnlineText = if ($lastOnlineValues.Count -gt 0) {
            ($lastOnlineValues | Sort-Object -Descending | Select-Object -First 1).ToString("yyyy-MM-dd HH:mm")
        }
        else { "" }

        $clients.Add([pscustomobject][ordered]@{
            resourceId = $resourceId
            device = [string](Get-ObjectValue $resource @("Name0") "(unnamed client)")
            user = [string](Get-ObjectValue $resource @("User_Name0") "")
            site = [string](Get-ObjectValue $resource @("Site_Code0") "")
            health = $health
            lastOnline = $lastOnlineText
            issue = (@($issues | Select-Object -Unique | Select-Object -First 3) -join "; ")
        })
    }
    return $clients.ToArray()
}

function Get-SqlContentDistribution {
    param(
        [string]$ConnectionString,
        [int]$CommandTimeoutSeconds,
        [int]$MaxRows,
        [string[]]$AvailableViews
    )

    $statusView = if ($AvailableViews -contains "v_ContentDistributionReport_DP") {
        "v_ContentDistributionReport_DP"
    }
    elseif ($AvailableViews -contains "v_DistributionStatus") {
        "v_DistributionStatus"
    }
    else {
        return @()
    }

    $statusRows = Get-TableRows (Invoke-SqlTable $ConnectionString (
        "SELECT TOP ({0}) * FROM dbo.{1}" -f $MaxRows, $statusView
    ) $CommandTimeoutSeconds)
    $messageRows = @()
    if ($AvailableViews -contains "v_ContentDistributionMessages") {
        $messageRows = Get-TableRows (Invoke-SqlTable $ConnectionString (
            "SELECT TOP ({0}) * FROM dbo.v_ContentDistributionMessages" -f $MaxRows
        ) $CommandTimeoutSeconds)
    }

    $packageRows = @()
    if ($AvailableViews -contains "v_Package") {
        $packageRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT * FROM dbo.v_Package" $CommandTimeoutSeconds)
    }
    elseif ($AvailableViews -contains "v_SMSPackage") {
        $packageRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT * FROM dbo.v_SMSPackage" $CommandTimeoutSeconds)
    }

    $packageLookup = @{}
    foreach ($package in $packageRows) {
        $packageId = [string](Get-ObjectValue $package @("PackageID", "PkgID") "")
        if (-not [string]::IsNullOrWhiteSpace($packageId)) {
            $packageLookup[$packageId.ToUpperInvariant()] = $package
        }
    }

    $messageLookup = @{}
    $packageMessageLookup = @{}
    foreach ($message in $messageRows) {
        $packageId = [string](Get-ObjectValue $message @("PackageID", "PkgID") "")
        $distributionPoint = Get-DistributionPointName $message
        $messageKey = "{0}|{1}" -f $packageId.ToUpperInvariant(), $distributionPoint
        Get-LatestLookupRow $messageLookup $messageKey $message @(
            "MessageTime", "LastUpdateDate", "LastStatusTime", "Time"
        )
        Get-LatestLookupRow $packageMessageLookup $packageId.ToUpperInvariant() $message @(
            "MessageTime", "LastUpdateDate", "LastStatusTime", "Time"
        )
    }

    $results = New-Object System.Collections.Generic.List[object]
    foreach ($row in $statusRows) {
        $packageId = [string](Get-ObjectValue $row @("PackageID", "PkgID", "Package_ID", "ContentID") "")
        $distributionPoint = Get-DistributionPointName $row
        $packageKey = $packageId.ToUpperInvariant()
        $messageKey = "{0}|{1}" -f $packageKey, $distributionPoint
        $message = if ($messageLookup.ContainsKey($messageKey)) {
            $messageLookup[$messageKey]
        }
        elseif ($packageMessageLookup.ContainsKey($packageKey)) {
            $packageMessageLookup[$packageKey]
        }
        else { $null }
        $package = if ($packageLookup.ContainsKey($packageKey)) { $packageLookup[$packageKey] } else { $null }

        $contentName = [string](Get-ObjectValue $row @(
            "Name", "PackageName", "SoftwareName", "ContentName"
        ) "")
        if ([string]::IsNullOrWhiteSpace($contentName) -and $null -ne $package) {
            $contentName = [string](Get-ObjectValue $package @("Name", "PackageName") "")
        }
        if ([string]::IsNullOrWhiteSpace($contentName)) { $contentName = $packageId }

        $errorCode = Get-ObjectValue $row @("ErrorCode", "MessageID", "StatusMessageID") $null
        if ($null -eq $errorCode -and $null -ne $message) {
            $errorCode = Get-ObjectValue $message @("ErrorCode", "MessageID", "StatusMessageID") $null
        }
        $errorMessage = [string](Get-ObjectValue $row @(
            "ErrorMessage", "Message", "MessageText", "Description", "InsString1"
        ) "")
        if ([string]::IsNullOrWhiteSpace($errorMessage) -and $null -ne $message) {
            $errorMessage = [string](Get-ObjectValue $message @(
                "ErrorMessage", "Message", "MessageText", "Description", "InsString1"
            ) "")
        }

        $results.Add([pscustomobject][ordered]@{
            distributionPoint = if ([string]::IsNullOrWhiteSpace($distributionPoint)) { "(unknown DP)" } else { $distributionPoint }
            packageId = $packageId
            contentName = if ([string]::IsNullOrWhiteSpace($contentName)) { "(unnamed content)" } else { $contentName }
            contentType = Get-ContentTypeName $(if ($null -ne $package) { $package } else { $row })
            site = [string](Get-ObjectValue $row @("SiteCode", "SourceSite", "SourceSiteCode") "")
            status = Get-ContentStatusName $row
            lastUpdate = Convert-DateForDisplay (Get-ObjectValue $row @(
                "LastUpdateDate", "LastStatusTime", "MessageTime", "SummarizationTime", "Time"
            ) "")
            errorCode = Format-ErrorCode $errorCode
            errorMessage = $errorMessage
        })
    }
    return $results.ToArray()
}

function Get-SqlOsdErrors {
    param(
        [string]$ConnectionString,
        [int]$CommandTimeoutSeconds,
        [int]$MaxRows,
        [string[]]$AvailableViews
    )

    if ($AvailableViews -notcontains "v_TaskExecutionStatus") { return @() }
    $select = "SELECT TOP ($MaxRows) tes.*"
    $from = " FROM dbo.v_TaskExecutionStatus tes"
    if ($AvailableViews -contains "v_Advertisement") {
        $select += ", adv.AdvertisementName AS MonitorDeploymentName"
        $from += " LEFT JOIN dbo.v_Advertisement adv ON tes.AdvertisementID = adv.AdvertisementID"
    }
    if ($AvailableViews -contains "v_R_System") {
        $select += ", rs.Name0 AS MonitorDeviceName"
        $from += " LEFT JOIN dbo.v_R_System rs ON tes.ResourceID = rs.ResourceID"
    }
    $rows = Get-TableRows (Invoke-SqlTable $ConnectionString ($select + $from) $CommandTimeoutSeconds)
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($row in $rows) {
        $rawExitCode = Get-ObjectValue $row @("ExitCode", "ActionExitCode", "ErrorCode", "ResultCode") $null
        $exitCode = [int64]0
        $hasNonZeroExitCode = $null -ne $rawExitCode -and
            [int64]::TryParse([string]$rawExitCode, [ref]$exitCode) -and $exitCode -ne 0
        $message = [string](Get-ObjectValue $row @(
            "ActionOutput", "StatusMessage", "Message", "Description", "Result"
        ) "")
        $statusText = [string](Get-ObjectValue $row @("Status", "StateName", "StatusName") "")
        if (-not $hasNonZeroExitCode -and ("{0} {1}" -f $statusText, $message) -notmatch "(?i)fail|error|fatal") {
            continue
        }

        $errorCodeValue = if ($null -ne $rawExitCode) {
            $rawExitCode
        }
        else {
            Get-ObjectValue $row @("LastStatusMessageID", "StatusMessageID") $null
        }
        $results.Add([pscustomobject][ordered]@{
            device = [string](Get-ObjectValue $row @(
                "MonitorDeviceName", "NetbiosName", "MachineName", "DeviceName"
            ) "(unknown device)")
            deployment = [string](Get-ObjectValue $row @(
                "MonitorDeploymentName", "AdvertisementName", "TaskSequenceName", "PackageName"
            ) "")
            advertisementId = [string](Get-ObjectValue $row @("AdvertisementID", "DeploymentID") "")
            packageId = [string](Get-ObjectValue $row @("PackageID", "PkgID") "")
            step = [string](Get-ObjectValue $row @("ActionName", "StepName", "Name") "(unknown step)")
            group = [string](Get-ObjectValue $row @("GroupName", "Group", "GroupID") "")
            errorCode = Format-ErrorCode $errorCodeValue
            errorMessage = $message
            occurred = Convert-DateForDisplay (Get-ObjectValue $row @(
                "ExecutionTime", "MessageTime", "LastStatusTime", "Time"
            ) "")
            resourceId = [string](Get-ObjectValue $row @("ResourceID") "")
        })
    }
    return $results.ToArray()
}

function Get-SqlClientInstallErrors {
    param(
        [string]$ConnectionString,
        [int]$CommandTimeoutSeconds,
        [int]$MaxRows,
        [string[]]$AvailableViews
    )

    if ($AvailableViews -notcontains "v_ClientDeploymentState") { return @() }
    $rows = Get-TableRows (Invoke-SqlTable $ConnectionString (
        "SELECT TOP ({0}) * FROM dbo.v_ClientDeploymentState" -f $MaxRows
    ) $CommandTimeoutSeconds)
    $stateRows = @()
    if ($AvailableViews -contains "v_StateNames") {
        $stateRows = Get-TableRows (Invoke-SqlTable $ConnectionString "SELECT * FROM dbo.v_StateNames" $CommandTimeoutSeconds)
    }
    $stateLookup = @{}
    foreach ($state in $stateRows) {
        $topicType = Convert-ToInt (Get-ObjectValue $state @("TopicType", "StateType") "-1") -1
        if ($topicType -eq 800) {
            $stateLookup[[string](Get-ObjectValue $state @("StateID") "")] =
                [string](Get-ObjectValue $state @("StateName") "")
        }
    }

    $results = New-Object System.Collections.Generic.List[object]
    foreach ($row in $rows) {
        $stateId = [string](Get-ObjectValue $row @("LastMessageStateID", "StateID") "")
        $stateName = [string](Get-ObjectValue $row @("StateName", "LastMessageStateName") "")
        if ([string]::IsNullOrWhiteSpace($stateName) -and $stateLookup.ContainsKey($stateId)) {
            $stateName = $stateLookup[$stateId]
        }
        $rawErrorCode = Get-ObjectValue $row @("LastErrorCode", "ErrorCode", "ExitCode", "ResultCode") $null
        $numericError = [int64]0
        $hasNonZeroError = $null -ne $rawErrorCode -and
            [int64]::TryParse([string]$rawErrorCode, [ref]$numericError) -and $numericError -ne 0
        $message = [string](Get-ObjectValue $row @(
            "LastMessageParam", "ErrorMessage", "Message", "Description"
        ) "")
        if (-not $hasNonZeroError -and ("{0} {1}" -f $stateName, $message) -notmatch "(?i)fail|error|fatal|unable") {
            continue
        }

        $displayCode = if ($null -ne $rawErrorCode) {
            Format-ErrorCode $rawErrorCode
        }
        elseif (-not [string]::IsNullOrWhiteSpace($stateId)) {
            "State {0}" -f $stateId
        }
        else { "" }
        $results.Add([pscustomobject][ordered]@{
            device = [string](Get-ObjectValue $row @(
                "NetBiosName", "NetBIOSName", "FQDN", "MachineName"
            ) "(unknown device)")
            site = [string](Get-ObjectValue $row @("AssignedSiteCode", "SiteCode") "")
            clientVersion = [string](Get-ObjectValue $row @("ClientVersion", "Version") "")
            state = if ([string]::IsNullOrWhiteSpace($stateName)) { "Installation failed" } else { $stateName }
            errorCode = $displayCode
            lastMessage = Convert-DateForDisplay (Get-ObjectValue $row @(
                "LastMessageTime", "MessageTime", "Time"
            ) "")
            details = $message
        })
    }
    return $results.ToArray()
}

function Convert-DeploymentRow {
    param($Row)

    $featureType = Convert-ToInt (Get-ObjectValue $Row @("FeatureType") "0") 0
    $type = switch ($featureType) {
        1 { "APP" }
        2 { "PACKAGE" }
        4 { "SCRIPT" }
        5 { "PATCH" }
        6 { "BASELINE" }
        7 { "OSD" }
        8 { "DISTRIBUTION" }
        9 { "DISTRIBUTION" }
        10 { "DPHEALTH" }
        default { "OTHER" }
    }
    $successful = Convert-ToInt (Get-ObjectValue $Row @("NumberSuccess") "0") 0
    $failed = Convert-ToInt (Get-ObjectValue $Row @("NumberErrors") "0") 0
    $inProgress = Convert-ToInt (Get-ObjectValue $Row @("NumberInProgress") "0") 0
    $unknown = (Convert-ToInt (Get-ObjectValue $Row @("NumberUnknown") "0") 0) +
        (Convert-ToInt (Get-ObjectValue $Row @("NumberOther") "0") 0)
    $targeted = Convert-ToInt (Get-ObjectValue $Row @("NumberTargeted") "0") 0
    $name = [string](Get-ObjectValue $Row @(
        "ApplicationName", "SoftwareName", "ProgramName", "PackageID", "DeploymentID"
    ) "Unnamed deployment")
    $progress = if ($targeted -gt 0) {
        [math]::Round((($successful + $failed) / [double]$targeted) * 100, 1)
    }
    else { 0 }

    return [pscustomobject][ordered]@{
        id = [string](Get-ObjectValue $Row @("DeploymentID", "AssignmentID", "PackageID") "")
        name = $name
        type = $type
        site = [string](Get-ObjectValue $Row @("SourceSiteCode", "SiteCode") "")
        collection = [string](Get-ObjectValue $Row @("CollectionName", "CollectionID") "")
        targeted = $targeted
        progress = [math]::Min(100, $progress)
        successful = $successful
        failed = $failed
        inProgress = $inProgress
        unknown = $unknown
        lastSummary = Convert-DateForDisplay (Get-ObjectValue $Row @("SummarizationTime", "ModificationTime") "")
    }
}

function Convert-AlertRow {
    param($Row)

    $severityValue = Convert-ToInt (Get-ObjectValue $Row @("Severity", "AlertSeverity") "3") 3
    $severity = switch ($severityValue) {
        1 { "Critical" }
        2 { "Warning" }
        3 { "Information" }
        default {
            $text = [string](Get-ObjectValue $Row @("SeverityName", "AlertSeverityName") "")
            if ($text -match "(?i)critical|error") { "Critical" }
            elseif ($text -match "(?i)warn") { "Warning" }
            else { "Information" }
        }
    }
    $message = [string](Get-ObjectValue $Row @(
        "RootCauseMessage", "AlertText", "Message", "Comments", "ParameterValues"
    ) "")
    return [pscustomobject][ordered]@{
        id = [string](Get-ObjectValue $Row @("ID", "AlertID", "RecordID") "")
        name = [string](Get-ObjectValue $Row @("Name", "AlertName", "Component") "MECM alert")
        severity = $severity
        site = [string](Get-ObjectValue $Row @("SourceSiteCode", "SiteCode") "")
        source = [string](Get-ObjectValue $Row @("InstanceNameParam1", "MachineName", "FeatureArea") "")
        modified = Convert-DateForDisplay (Get-ObjectValue $Row @("DateLastModified", "DateCreated", "Time") "")
        message = $message
        occurrences = Convert-ToInt (Get-ObjectValue $Row @("OccurrenceCount") "1") 1
    }
}

function New-Metric {
    param([int]$Successful, [int]$Failed, [int]$InProgress, [int]$Unknown)

    $total = $Successful + $Failed + $InProgress + $Unknown
    [pscustomobject][ordered]@{
        successRate = if ($total -gt 0) { [math]::Round(($Successful / [double]$total) * 100, 1) } else { 0 }
        successful = $Successful
        failed = $Failed
        inProgress = $InProgress
        unknown = $Unknown
        total = $total
    }
}

function Get-PropertySum {
    param([object[]]$Rows, [string]$Property)

    if ($null -eq $Rows -or $Rows.Count -eq 0) { return 0 }
    $measurement = $Rows | Measure-Object -Property $Property -Sum
    if ($null -eq $measurement -or $null -eq $measurement.Sum) { return 0 }
    return [int]$measurement.Sum
}

function New-MetricFromDeployments {
    param([object[]]$Rows, [string[]]$Types)

    $selected = @($Rows | Where-Object { $Types -contains [string]$_.type })
    New-Metric `
        -Successful (Get-PropertySum $selected "successful") `
        -Failed (Get-PropertySum $selected "failed") `
        -InProgress (Get-PropertySum $selected "inProgress") `
        -Unknown (Get-PropertySum $selected "unknown")
}

try {
    if (-not (Test-Path -LiteralPath $ConfigPath)) { throw "Configuration file not found: $ConfigPath" }
    [xml]$config = Get-Content -LiteralPath $ConfigPath -Raw
    if ($null -eq $config.MECMMonitor) { throw "The XML root element must be MECMMonitor." }

    $general = $config.MECMMonitor.General
    $title = [string](Get-XmlValue $general "Title" "MECM Command Center")
    $environmentName = [string](Get-XmlValue $general "EnvironmentName" "MECM")
    $siteCode = [string](Get-XmlValue $general "PrimarySiteCode" (Get-XmlValue $general "SiteCode" ""))
    $refreshSeconds = [math]::Max(10, (Convert-ToInt (Get-XmlValue $general "RefreshSeconds" "30") 30))
    $staleAfterMinutes = [math]::Max(1, (Convert-ToInt (Get-XmlValue $general "StaleAfterMinutes" "10") 10))
    $clientPageSize = [math]::Max(25, (Convert-ToInt (Get-XmlValue $general "ClientPageSize" "100") 100))
    $responseWarningMs = Convert-ToInt (Get-XmlValue $config.MECMMonitor.Thresholds "ResponseWarningMs" "2000") 2000
    Add-Diagnostic "Configuration" "Information" ("Loaded automatic collection settings for {0}." -f $environmentName)

    $infrastructure = New-Object System.Collections.Generic.List[object]
    foreach ($server in @($config.MECMMonitor.Infrastructure.Server)) {
        $enabled = Convert-ToBoolean (Get-XmlValue $server "Enabled" "true") $true
        if (-not $enabled) { continue }
        $fqdn = [string](Get-XmlValue $server "Fqdn")
        $port = Convert-ToInt (Get-XmlValue $server "Port" "443") 443
        $probe = Test-TcpEndpoint -ComputerName $fqdn -Port $port
        $status = if (-not $probe.reachable) { "Offline" }
            elseif ($probe.responseMs -gt $responseWarningMs) { "Degraded" }
            else { "Online" }
        $infrastructure.Add([pscustomobject][ordered]@{
            name = [string](Get-XmlValue $server "Name" (Normalize-ServerName $fqdn))
            fqdn = $fqdn
            role = [string](Get-XmlValue $server "Role" "Site System")
            siteCode = [string](Get-XmlValue $server "SiteCode" $siteCode)
            port = $port
            status = $status
            responseMs = $probe.responseMs
            percentFree = $null
            uptime = ""
            note = if ($probe.reachable) { "TCP endpoint is reachable" } else { $probe.error }
            source = "XML + TCP probe"
        })
    }
    Add-Diagnostic "Infrastructure probes" "Information" ("Probed {0} enabled server endpoints from XML." -f $infrastructure.Count)

    $deployments = New-Object System.Collections.Generic.List[object]
    $components = New-Object System.Collections.Generic.List[object]
    $alerts = New-Object System.Collections.Generic.List[object]
    $clients = @()
    $distributionStatus = @()
    $osdErrors = @()
    $clientInstallErrors = @()

    $admin = $config.MECMMonitor.AdminService
    $adminEnabled = Convert-ToBoolean (Get-XmlValue $admin "Enabled" "false") $false
    if ($adminEnabled) {
        $provider = [string](Get-XmlValue $admin "ProviderFqdn")
        $adminPort = Convert-ToInt (Get-XmlValue $admin "Port" "443") 443
        $timeout = Convert-ToInt (Get-XmlValue $admin "TimeoutSeconds" "45") 45
        $maxDeployments = [math]::Max(1, (Convert-ToInt (Get-XmlValue $admin "MaxDeployments" "500") 500))
        $maxAlerts = [math]::Max(1, (Convert-ToInt (Get-XmlValue $admin "MaxAlerts" "200") 200))
        $tally = [string](Get-XmlValue $admin "ComponentTallyInterval" "0001128000100008")
        if ($tally -notmatch "^[0-9A-Fa-f]{16}$") { $tally = "0001128000100008" }
        $baseUri = "https://{0}:{1}/AdminService/wmi" -f $provider, $adminPort
        try {
            $sites = @(Invoke-AdminServiceQuery $baseUri "SMS_Site?`$select=SiteCode,SiteName,ServerName,Status" $timeout)
            if ([string]::IsNullOrWhiteSpace($siteCode) -and $sites.Count -gt 0) {
                $siteCode = [string](Get-ObjectValue $sites[0] @("SiteCode") "")
            }
            Add-Diagnostic "AdminService" "Information" ("Connected to {0}; discovered {1} site record(s)." -f $provider, $sites.Count)
        }
        catch {
            Add-Diagnostic "AdminService" "Error" ("Connection failed: {0}" -f $_.Exception.Message)
        }

        try {
            $siteSystems = @(Invoke-AdminServiceQuery $baseUri "SMS_SiteSystemSummarizer" $timeout)
            foreach ($row in $siteSystems) {
                $machine = Normalize-ServerName ([string](Get-ObjectValue $row @("SiteSystem", "MachineName", "ServerName") ""))
                $matching = @($infrastructure | Where-Object {
                    (Normalize-ServerName $_.name) -eq $machine -or (Normalize-ServerName $_.fqdn) -eq $machine
                })
                foreach ($system in $matching) {
                    $system.status = switch (Convert-ToInt (Get-ObjectValue $row @("Status") "0") 0) {
                        0 { if ($system.status -eq "Offline") { "Offline" } else { "Online" } }
                        1 { "Degraded" }
                        2 { "Offline" }
                        default { $system.status }
                    }
                    $percentFree = Get-ObjectValue $row @("PercentFree") $null
                    if ($null -ne $percentFree) { $system.percentFree = Convert-ToDouble $percentFree 0 }
                    $system.note = "MECM site-system summarizer merged with TCP availability"
                    $system.source = "AdminService + TCP probe"
                }
            }
            Add-Diagnostic "Site-system health" "Information" ("Merged {0} MECM site-system summary row(s)." -f $siteSystems.Count)
        }
        catch {
            Add-Diagnostic "Site-system health" "Warning" ("Could not read SMS_SiteSystemSummarizer: {0}" -f $_.Exception.Message)
        }

        try {
            $deploymentRows = @(Invoke-AdminServiceQuery $baseUri ("SMS_DeploymentSummary?`$filter=NumberTargeted%20gt%200&`$top={0}" -f $maxDeployments) $timeout)
            foreach ($row in $deploymentRows) { $deployments.Add((Convert-DeploymentRow $row)) }
            Add-Diagnostic "Deployment summaries" "Information" ("Collected {0} OSD, update, application, package, and content summaries." -f $deployments.Count)
        }
        catch {
            Add-Diagnostic "Deployment summaries" "Error" ("Could not read SMS_DeploymentSummary: {0}" -f $_.Exception.Message)
        }

        try {
            $componentPath = "SMS_ComponentSummarizer?`$filter=TallyInterval%20eq%20%27{0}%27" -f $tally
            $componentRows = @(Invoke-AdminServiceQuery $baseUri $componentPath $timeout)
            foreach ($row in $componentRows) {
                $status = Convert-MecmHealthStatus (Convert-ToInt (Get-ObjectValue $row @("Status") "3") 3)
                $stateNumber = Convert-ToInt (Get-ObjectValue $row @("State") "0") 0
                $state = switch ($stateNumber) {
                    0 { "Stopped" }
                    1 { "Started" }
                    2 { "Paused" }
                    3 { "Installing" }
                    4 { "Reinstalling" }
                    5 { "Deinstalling" }
                    default { "Unknown" }
                }
                $errors = Convert-ToInt (Get-ObjectValue $row @("Errors") "0") 0
                $warnings = Convert-ToInt (Get-ObjectValue $row @("Warnings") "0") 0
                $components.Add([pscustomobject][ordered]@{
                    name = [string](Get-ObjectValue $row @("ComponentName") "Unknown component")
                    server = [string](Get-ObjectValue $row @("MachineName") "")
                    site = [string](Get-ObjectValue $row @("SiteCode") $siteCode)
                    state = $state
                    status = $status
                    lastMessage = Convert-DateForDisplay (Get-ObjectValue $row @("LastContacted", "LastHeartbeat") "")
                    message = ("{0} error(s), {1} warning(s) in tally interval" -f $errors, $warnings)
                })
            }
            Add-Diagnostic "Component health" "Information" ("Collected {0} component summarizer row(s)." -f $components.Count)
        }
        catch {
            Add-Diagnostic "Component health" "Warning" ("Could not read SMS_ComponentSummarizer: {0}" -f $_.Exception.Message)
        }

        try {
            $alertRows = @(Invoke-AdminServiceQuery $baseUri ("SMS_Alert?`$filter=AlertState%20eq%200%20and%20Enabled%20eq%20true&`$top={0}" -f $maxAlerts) $timeout)
            foreach ($row in $alertRows) { $alerts.Add((Convert-AlertRow $row)) }
            Add-Diagnostic "Active alerts" "Information" ("Collected {0} active MECM alert(s)." -f $alerts.Count)
        }
        catch {
            Add-Diagnostic "Active alerts" "Warning" ("Could not read SMS_Alert: {0}" -f $_.Exception.Message)
        }
    }
    else {
        Add-Diagnostic "AdminService" "Warning" "Disabled in XML. Deployment, component, and active-alert data will remain empty until enabled."
    }

    $sql = $config.MECMMonitor.Sql
    $sqlEnabled = Convert-ToBoolean (Get-XmlValue $sql "Enabled" "false") $false
    if ($sqlEnabled) {
        try {
            $connectionString = New-SqlConnectionString $sql
            $commandTimeout = Convert-ToInt (Get-XmlValue $sql "CommandTimeoutSeconds" "120") 120
            $maxClients = [math]::Max(0, (Convert-ToInt (Get-XmlValue $sql "MaxClients" "0") 0))
            $maxDetailRows = [math]::Max(100, (Convert-ToInt (Get-XmlValue $sql "MaxDetailRows" "10000") 10000))
            $viewTable = Invoke-SqlTable $connectionString @"
SELECT name
FROM sys.views
WHERE name IN (
    'v_R_System',
    'v_CH_ClientSummary',
    'v_CH_EvalResults',
    'v_StateNames',
    'v_SMS_Alert',
    'v_ComponentSummarizer',
    'v_ContentDistributionReport_DP',
    'v_ContentDistributionMessages',
    'v_DistributionStatus',
    'v_Package',
    'v_SMSPackage',
    'v_TaskExecutionStatus',
    'v_Advertisement',
    'v_ClientDeploymentState'
)
"@ $commandTimeout
            $availableViews = @(Get-TableRows $viewTable | ForEach-Object {
                [string](Get-ObjectValue $_ @("name") "")
            })
            try {
                $clients = @(Get-SqlClients $connectionString $commandTimeout $maxClients $availableViews)
                Add-Diagnostic "SQL client health" "Information" (
                    "Collected {0} managed client row(s), including evaluation errors when reported." -f $clients.Count
                )
            }
            catch {
                Add-Diagnostic "SQL client health" "Warning" (
                    "Could not collect managed-client health: {0}" -f $_.Exception.Message
                )
            }

            if ($availableViews -contains "v_ContentDistributionReport_DP" -or
                $availableViews -contains "v_DistributionStatus") {
                try {
                    $distributionStatus = @(Get-SqlContentDistribution `
                        $connectionString $commandTimeout $maxDetailRows $availableViews)
                    $failedDistribution = @($distributionStatus | Where-Object {
                        $_.status -match "(?i)fail|error"
                    }).Count
                    Add-Diagnostic "SQL content distribution" "Information" (
                        "Collected {0} per-DP content row(s); {1} currently failed." -f
                        $distributionStatus.Count, $failedDistribution
                    )
                }
                catch {
                    Add-Diagnostic "SQL content distribution" "Warning" (
                        "Could not collect per-DP content status: {0}" -f $_.Exception.Message
                    )
                }
            }
            else {
                Add-Diagnostic "SQL content distribution" "Warning" (
                    "v_ContentDistributionReport_DP and v_DistributionStatus are unavailable."
                )
            }

            if ($availableViews -contains "v_TaskExecutionStatus") {
                try {
                    $osdErrors = @(Get-SqlOsdErrors `
                        $connectionString $commandTimeout $maxDetailRows $availableViews)
                    Add-Diagnostic "SQL OSD step failures" "Information" (
                        "Collected {0} failed task-sequence step row(s)." -f $osdErrors.Count
                    )
                }
                catch {
                    Add-Diagnostic "SQL OSD step failures" "Warning" (
                        "Could not collect task-sequence step failures: {0}" -f $_.Exception.Message
                    )
                }
            }
            else {
                Add-Diagnostic "SQL OSD step failures" "Warning" "v_TaskExecutionStatus is unavailable."
            }

            if ($availableViews -contains "v_ClientDeploymentState") {
                try {
                    $clientInstallErrors = @(Get-SqlClientInstallErrors `
                        $connectionString $commandTimeout $maxDetailRows $availableViews)
                    Add-Diagnostic "SQL client installation" "Information" (
                        "Collected {0} failed client-installation row(s)." -f $clientInstallErrors.Count
                    )
                }
                catch {
                    Add-Diagnostic "SQL client installation" "Warning" (
                        "Could not collect client-installation failures: {0}" -f $_.Exception.Message
                    )
                }
            }
            else {
                Add-Diagnostic "SQL client installation" "Warning" "v_ClientDeploymentState is unavailable."
            }

            if ($alerts.Count -eq 0 -and $availableViews -contains "v_SMS_Alert") {
                $maxAlerts = [math]::Max(1, (Convert-ToInt (Get-XmlValue $admin "MaxAlerts" "200") 200))
                $sqlAlerts = Get-TableRows (Invoke-SqlTable $connectionString @"
SELECT TOP ($maxAlerts) *
FROM dbo.v_SMS_Alert
WHERE AlertState = 0 AND Enabled = 1
ORDER BY Severity, DateLastModified DESC
"@ $commandTimeout)
                foreach ($row in $sqlAlerts) { $alerts.Add((Convert-AlertRow $row)) }
                Add-Diagnostic "SQL active-alert fallback" "Information" ("Collected {0} active alert row(s) from v_SMS_Alert." -f $sqlAlerts.Count)
            }
        }
        catch {
            Add-Diagnostic "SQL reporting database" "Error" ("Automatic client-health collection failed: {0}" -f $_.Exception.Message)
        }
    }
    else {
        Add-Diagnostic "SQL reporting database" "Warning" "Disabled in XML. Client health, per-DP content, OSD step failures, and client-install errors will remain empty until enabled."
    }

    $clientHealthy = @($clients | Where-Object health -eq "Healthy").Count
    $clientCritical = @($clients | Where-Object health -eq "Critical").Count
    $clientWarning = @($clients | Where-Object health -eq "Warning").Count
    $clientUnknown = @($clients | Where-Object health -eq "Unknown").Count
    $metrics = [pscustomobject][ordered]@{
        osd = New-MetricFromDeployments -Rows ($deployments.ToArray()) -Types @("OSD")
        patching = New-MetricFromDeployments -Rows ($deployments.ToArray()) -Types @("PATCH")
        software = New-MetricFromDeployments -Rows ($deployments.ToArray()) -Types @("APP", "PACKAGE", "DISTRIBUTION")
        clients = New-Metric $clientHealthy $clientCritical $clientWarning $clientUnknown
    }

    $onlineCount = @($infrastructure | Where-Object status -eq "Online").Count
    $offlineCount = @($infrastructure | Where-Object status -eq "Offline").Count
    $degradedCount = @($infrastructure | Where-Object status -eq "Degraded").Count
    $criticalComponents = @($components | Where-Object status -eq "Critical").Count
    $warningComponents = @($components | Where-Object status -eq "Warning").Count
    $criticalAlerts = @($alerts | Where-Object severity -eq "Critical").Count
    $warningAlerts = @($alerts | Where-Object severity -eq "Warning").Count
    $dataState = if (-not $adminEnabled -and -not $sqlEnabled -and $infrastructure.Count -eq 0) {
        "ConfigurationRequired"
    }
    elseif (-not $adminEnabled -or -not $sqlEnabled) {
        "Partial"
    }
    else {
        "Connected"
    }
    $healthScore = if ($dataState -eq "ConfigurationRequired") {
        0
    }
    else {
        [math]::Max(0, 100 -
        ($offlineCount * 10) -
        ($degradedCount * 4) -
        ($criticalComponents * 4) -
        ($warningComponents * 2) -
        ($criticalAlerts * 2) -
        $warningAlerts
        )
    }

    $payload = [pscustomobject][ordered]@{
        schemaVersion = 1
        generatedAtUtc = [DateTime]::UtcNow.ToString("o")
        title = $title
        environmentName = $environmentName
        siteCode = $siteCode
        mode = "Automatic"
        dataState = $dataState
        refreshSeconds = $refreshSeconds
        staleAfterMinutes = $staleAfterMinutes
        clientPageSize = $clientPageSize
        healthScore = $healthScore
        summary = [pscustomobject][ordered]@{
            systemsTotal = $infrastructure.Count
            systemsOnline = $onlineCount
            systemsOffline = $offlineCount
            systemsDegraded = $degradedCount
            activeAlerts = $alerts.Count
            criticalAlerts = $criticalAlerts
            warningAlerts = $warningAlerts
            infrastructureConditions = $offlineCount + $degradedCount + $criticalComponents + $warningComponents
            managedClients = $clients.Count
            failedContentDistributions = @($distributionStatus | Where-Object {
                $_.status -match "(?i)fail|error"
            }).Count
            osdStepFailures = $osdErrors.Count
            clientInstallFailures = $clientInstallErrors.Count
        }
        metrics = $metrics
        infrastructure = $infrastructure.ToArray()
        components = $components.ToArray()
        deployments = @($deployments.ToArray() | Sort-Object failed, inProgress -Descending)
        alerts = @($alerts.ToArray() | Sort-Object @{ Expression = {
            switch ($_.severity) { "Critical" { 0 } "Warning" { 1 } default { 2 } }
        } }, modified)
        clientWatchlist = @($clients | Sort-Object @{ Expression = {
            switch ($_.health) { "Critical" { 0 } "Warning" { 1 } "Unknown" { 2 } default { 3 } }
        } }, device)
        distributionStatus = @($distributionStatus | Sort-Object @{ Expression = {
            if ($_.status -match "(?i)fail|error") { 0 }
            elseif ($_.status -match "(?i)retry|progress|pending") { 1 }
            else { 2 }
        } }, distributionPoint, contentName)
        osdErrors = @($osdErrors | Sort-Object occurred -Descending)
        clientInstallErrors = @($clientInstallErrors | Sort-Object lastMessage -Descending)
        diagnostics = $script:Diagnostics.ToArray()
    }

    $outputDirectory = Split-Path -Parent $OutputPath
    if (-not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
    }
    $temporaryOutput = Join-Path $outputDirectory (".dashboard.{0}.tmp" -f [guid]::NewGuid().ToString("N"))
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($temporaryOutput, ($payload | ConvertTo-Json -Depth 12), $utf8NoBom)
    Move-Item -LiteralPath $temporaryOutput -Destination $OutputPath -Force
    Write-CollectorLog "Information" ("Wrote automatic dashboard snapshot to {0}." -f $OutputPath)
    Write-Output $OutputPath
    exit 0
}
catch {
    try { Write-CollectorLog "Error" $_.Exception.ToString() } catch { }
    Write-Error $_
    exit 1
}
