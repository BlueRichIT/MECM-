[CmdletBinding()]
param(
    [string]$ConfigPath,
    [string]$CollectorPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$dataRoot = "C:\ProgramData\MECMHealthMonitor"
if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $installedConfig = Join-Path $dataRoot "MECMMonitor.xml"
    $packageConfig = Join-Path (Split-Path $PSScriptRoot -Parent) "Config\MECMMonitor.xml"
    $ConfigPath = if (Test-Path -LiteralPath $installedConfig) { $installedConfig } else { $packageConfig }
}
if ([string]::IsNullOrWhiteSpace($CollectorPath)) {
    $installedCollector = Join-Path $dataRoot "Collector\Collect-MECMHealth.ps1"
    $packageCollector = Join-Path $PSScriptRoot "Collect-MECMHealth.ps1"
    $CollectorPath = if (Test-Path -LiteralPath $installedCollector) { $installedCollector } else { $packageCollector }
}

$testRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("MECMMonitorTest-{0}" -f [guid]::NewGuid().ToString("N"))
$testOutput = Join-Path $testRoot "dashboard.json"
$testLog = Join-Path $testRoot "collector.log"

try {
    New-Item -ItemType Directory -Path $testRoot -Force | Out-Null

    if (-not (Test-Path -LiteralPath $ConfigPath)) {
        throw "Configuration not found: $ConfigPath"
    }
    if (-not (Test-Path -LiteralPath $CollectorPath)) {
        throw "Collector not found: $CollectorPath"
    }
    [xml]$configuration = Get-Content -LiteralPath $ConfigPath -Raw
    $manualProperty = $configuration.MECMMonitor.PSObject.Properties["ManualData"]
    $componentsProperty = $configuration.MECMMonitor.PSObject.Properties["Components"]
    if ($null -ne $manualProperty -or $null -ne $componentsProperty) {
        throw "MECMMonitor.xml must contain configuration only; manual operational data was found."
    }

    $tokens = $null
    $parseErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile(
        $CollectorPath,
        [ref]$tokens,
        [ref]$parseErrors
    ) | Out-Null
    if ($parseErrors.Count -gt 0) {
        throw ("Collector has PowerShell parse errors: {0}" -f (($parseErrors | ForEach-Object Message) -join "; "))
    }

    & $CollectorPath -ConfigPath $ConfigPath -OutputPath $testOutput -LogPath $testLog
    if ($LASTEXITCODE -ne 0) {
        throw "Collector returned exit code $LASTEXITCODE."
    }
    if (-not (Test-Path -LiteralPath $testOutput)) {
        throw "Collector did not create dashboard.json."
    }

    $data = Get-Content -LiteralPath $testOutput -Raw | ConvertFrom-Json
    $required = @(
        "schemaVersion",
        "generatedAtUtc",
        "dataState",
        "metrics",
        "summary",
        "infrastructure",
        "components",
        "deployments",
        "alerts",
        "clientWatchlist",
        "distributionStatus",
        "osdErrors",
        "clientInstallErrors"
    )
    foreach ($property in $required) {
        if ($null -eq $data.PSObject.Properties[$property]) {
            throw "Output is missing required property: $property"
        }
    }
    if ($data.schemaVersion -ne 1) {
        throw "Unexpected schema version: $($data.schemaVersion)"
    }
    if ([int]$data.healthScore -lt 0 -or [int]$data.healthScore -gt 100) {
        throw "Health score must be between 0 and 100."
    }

    Write-Host "PASS: XML contains connection and server configuration only." -ForegroundColor Green
    Write-Host "PASS: Collector PowerShell syntax is valid." -ForegroundColor Green
    Write-Host "PASS: Dashboard JSON schema is valid." -ForegroundColor Green
    Write-Host ("PASS: {0} infrastructure systems, {1} components, and {2} deployments generated." -f `
        @($data.infrastructure).Count, @($data.components).Count, @($data.deployments).Count) -ForegroundColor Green
}
finally {
    if (Test-Path -LiteralPath $testRoot) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force
    }
}
