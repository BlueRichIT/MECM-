#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$SiteName = "MECM Health Monitor",
    [string]$AppPoolName = "MECMHealthMonitor",
    [string]$WebRoot = "C:\inetpub\MECMHealthMonitor",
    [string]$DataRoot = "C:\ProgramData\MECMHealthMonitor",
    [ValidateRange(1, 65535)]
    [int]$Port = 8088,
    [ValidateRange(1, 60)]
    [int]$CollectionIntervalMinutes = 2,
    [string]$TaskUser = "NT AUTHORITY\SYSTEM",
    [System.Management.Automation.PSCredential]$TaskCredential,
    [bool]$EnableWindowsAuthentication = $true,
    [string]$AllowedRemoteAddress = "LocalSubnet"
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$sourceRoot = $PSScriptRoot
$sourceWeb = Join-Path $sourceRoot "wwwroot"
$sourceConfig = Join-Path $sourceRoot "Config\MECMMonitor.xml"
$sourceCollector = Join-Path $sourceRoot "Collector"
$sourceQueries = Join-Path $sourceRoot "Queries"
$installedConfig = Join-Path $DataRoot "MECMMonitor.xml"
$installedCollector = Join-Path $DataRoot "Collector"
$installedQueries = Join-Path $DataRoot "Queries"
$installedLogs = Join-Path $DataRoot "Logs"
$dashboardOutput = Join-Path $WebRoot "data\dashboard.json"
$taskName = "MECM Health Monitor - Collect"
$firewallName = "MECM Health Monitor IIS TCP $Port"

function Write-Step {
    param([string]$Message)
    Write-Host ("[MECM Monitor] {0}" -f $Message) -ForegroundColor Cyan
}

if (-not (Test-Path -LiteralPath $sourceWeb)) {
    throw "Package is incomplete. Missing: $sourceWeb"
}
if (-not (Test-Path -LiteralPath $sourceConfig)) {
    throw "Package is incomplete. Missing: $sourceConfig"
}

Write-Step "Installing IIS features."
Import-Module ServerManager
$features = @(
    "Web-Server",
    "Web-Static-Content",
    "Web-Default-Doc",
    "Web-Http-Logging",
    "Web-Filtering",
    "Web-Mgmt-Console"
)
if ($EnableWindowsAuthentication) {
    $features += "Web-Windows-Auth"
}
$featureResult = Install-WindowsFeature -Name $features -IncludeManagementTools
if (-not $featureResult.Success) {
    throw "One or more IIS features could not be installed."
}

Write-Step "Copying website and collector files."
New-Item -ItemType Directory -Path $WebRoot -Force | Out-Null
New-Item -ItemType Directory -Path $DataRoot -Force | Out-Null
New-Item -ItemType Directory -Path $installedCollector -Force | Out-Null
New-Item -ItemType Directory -Path $installedQueries -Force | Out-Null
New-Item -ItemType Directory -Path $installedLogs -Force | Out-Null

Copy-Item -Path (Join-Path $sourceWeb "*") -Destination $WebRoot -Recurse -Force
Copy-Item -Path (Join-Path $sourceCollector "*") -Destination $installedCollector -Recurse -Force
Copy-Item -Path (Join-Path $sourceQueries "*") -Destination $installedQueries -Recurse -Force
if (-not (Test-Path -LiteralPath $installedConfig)) {
    Copy-Item -LiteralPath $sourceConfig -Destination $installedConfig
    Write-Step "Created a new XML configuration."
}
else {
    Write-Step "Preserved the existing XML configuration."
    try {
        [xml]$existingConfiguration = Get-Content -LiteralPath $installedConfig -Raw
        if ($null -ne $existingConfiguration.MECMMonitor.ManualData -or
            $null -ne $existingConfiguration.MECMMonitor.Components) {
            Write-Warning "The preserved XML uses the older manual-data format. The new collector ignores manual operational data. Compare it with Config\MECMMonitor.xml in this package."
        }
    }
    catch {
        Write-Warning "The preserved XML could not be inspected. Collector validation will report any configuration problem."
    }
}

& icacls.exe $WebRoot /grant "IIS_IUSRS:(OI)(CI)(RX)" /T /C | Out-Null
$effectiveTaskUser = if ($null -ne $TaskCredential) { $TaskCredential.UserName } else { $TaskUser }
& icacls.exe $DataRoot /grant "${effectiveTaskUser}:(OI)(CI)(RX)" /T /C | Out-Null
& icacls.exe $installedLogs /grant "${effectiveTaskUser}:(OI)(CI)(M)" /T /C | Out-Null
& icacls.exe (Join-Path $WebRoot "data") /grant "${effectiveTaskUser}:(OI)(CI)(M)" /T /C | Out-Null

Write-Step "Configuring the IIS application pool and website."
Import-Module WebAdministration

$conflictingBinding = Get-WebBinding -Protocol "http" -Port $Port -ErrorAction SilentlyContinue |
    Where-Object { $_.ItemXPath -notmatch [regex]::Escape($SiteName) }
if ($conflictingBinding) {
    throw "TCP port $Port is already bound to another IIS website."
}

if (-not (Test-Path "IIS:\AppPools\$AppPoolName")) {
    New-WebAppPool -Name $AppPoolName | Out-Null
}
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name managedRuntimeVersion -Value ""
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name startMode -Value "AlwaysRunning"

if (-not (Test-Path "IIS:\Sites\$SiteName")) {
    New-Website -Name $SiteName -PhysicalPath $WebRoot -Port $Port -ApplicationPool $AppPoolName | Out-Null
}
else {
    Set-ItemProperty "IIS:\Sites\$SiteName" -Name physicalPath -Value $WebRoot
    Set-ItemProperty "IIS:\Sites\$SiteName" -Name applicationPool -Value $AppPoolName
    if (-not (Get-WebBinding -Name $SiteName -Protocol "http" -Port $Port -ErrorAction SilentlyContinue)) {
        New-WebBinding -Name $SiteName -Protocol "http" -Port $Port | Out-Null
    }
}

if ($EnableWindowsAuthentication) {
    Set-WebConfigurationProperty -PSPath "IIS:\" -Location $SiteName `
        -Filter "system.webServer/security/authentication/windowsAuthentication" `
        -Name enabled -Value $true
    Set-WebConfigurationProperty -PSPath "IIS:\" -Location $SiteName `
        -Filter "system.webServer/security/authentication/anonymousAuthentication" `
        -Name enabled -Value $false
}
else {
    Set-WebConfigurationProperty -PSPath "IIS:\" -Location $SiteName `
        -Filter "system.webServer/security/authentication/windowsAuthentication" `
        -Name enabled -Value $false
    Set-WebConfigurationProperty -PSPath "IIS:\" -Location $SiteName `
        -Filter "system.webServer/security/authentication/anonymousAuthentication" `
        -Name enabled -Value $true
}

Start-WebAppPool -Name $AppPoolName -ErrorAction SilentlyContinue
Start-Website -Name $SiteName -ErrorAction SilentlyContinue

Write-Step "Creating the restricted Windows Firewall rule."
$existingFirewall = Get-NetFirewallRule -DisplayName $firewallName -ErrorAction SilentlyContinue
if (-not $existingFirewall) {
    New-NetFirewallRule -DisplayName $firewallName -Direction Inbound -Action Allow `
        -Protocol TCP -LocalPort $Port -Profile Domain -RemoteAddress $AllowedRemoteAddress |
        Out-Null
}

Write-Step "Registering the collection scheduled task."
$collectorScript = Join-Path $installedCollector "Collect-MECMHealth.ps1"
$collectorLog = Join-Path $installedLogs "collector.log"
$powerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "{0}" -ConfigPath "{1}" -OutputPath "{2}" -LogPath "{3}"' -f `
    $collectorScript, $installedConfig, $dashboardOutput, $collectorLog
$action = New-ScheduledTaskAction -Execute $powerShellExe -Argument $arguments
$triggers = @(
    (New-ScheduledTaskTrigger -AtStartup),
    (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
        -RepetitionInterval (New-TimeSpan -Minutes $CollectionIntervalMinutes) `
        -RepetitionDuration (New-TimeSpan -Days 3650))
)
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1)

if ($null -ne $TaskCredential) {
    $principal = New-ScheduledTaskPrincipal -UserId $TaskCredential.UserName -LogonType Password -RunLevel Highest
}
elseif ($TaskUser -eq "NT AUTHORITY\SYSTEM" -or $TaskUser -eq "SYSTEM") {
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
}
elseif ($TaskUser.EndsWith("$")) {
    $principal = New-ScheduledTaskPrincipal -UserId $TaskUser -LogonType ServiceAccount -RunLevel Highest
}
else {
    if ($null -eq $TaskCredential) {
        throw "TaskCredential is required for a normal domain account. Prefer a gMSA ending in `$."
    }
    $principal = New-ScheduledTaskPrincipal -UserId $TaskCredential.UserName -LogonType Password -RunLevel Highest
}

$task = New-ScheduledTask -Action $action -Trigger $triggers -Settings $settings -Principal $principal
if ($null -ne $TaskCredential) {
    Register-ScheduledTask -TaskName $taskName -InputObject $task -User $TaskCredential.UserName `
        -Password $TaskCredential.GetNetworkCredential().Password -Force | Out-Null
}
else {
    Register-ScheduledTask -TaskName $taskName -InputObject $task -Force | Out-Null
}

Write-Step "Generating and validating the first dashboard snapshot."
& $powerShellExe -NoProfile -NonInteractive -ExecutionPolicy Bypass `
    -File $collectorScript -ConfigPath $installedConfig -OutputPath $dashboardOutput -LogPath $collectorLog
if ($LASTEXITCODE -ne 0) {
    throw "The collector failed during initial validation. Review $collectorLog"
}

$snapshot = Get-Content -LiteralPath $dashboardOutput -Raw | ConvertFrom-Json
if ($snapshot.schemaVersion -ne 1 -or $null -eq $snapshot.metrics -or $null -eq $snapshot.infrastructure) {
    throw "The generated dashboard snapshot failed schema validation."
}

Write-Host ""
Write-Host "MECM Health Monitor installation completed." -ForegroundColor Green
Write-Host ("Website: http://{0}:{1}" -f $env:COMPUTERNAME, $Port)
Write-Host ("Configuration: {0}" -f $installedConfig)
Write-Host ("Scheduled task: {0}" -f $taskName)
Write-Host ""
Write-Host "Next: edit only the server/AdminService/SQL settings in MECMMonitor.xml, enable them, and run the scheduled task."
Write-Host "OSD, patching, software, client health, components, and alerts are collected automatically."
