#requires -RunAsAdministrator
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = "High")]
param(
    [string]$SiteName = "MECM Health Monitor",
    [string]$AppPoolName = "MECMHealthMonitor",
    [string]$WebRoot = "C:\inetpub\MECMHealthMonitor",
    [string]$DataRoot = "C:\ProgramData\MECMHealthMonitor",
    [int]$Port = 8088,
    [switch]$RemoveData
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$taskName = "MECM Health Monitor - Collect"
$firewallName = "MECM Health Monitor IIS TCP $Port"

if (-not $PSCmdlet.ShouldProcess($env:COMPUTERNAME, "Remove the MECM Health Monitor IIS site and scheduled task")) {
    return
}

Import-Module WebAdministration
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}
if (Test-Path "IIS:\Sites\$SiteName") {
    Remove-Website -Name $SiteName
}
if (Test-Path "IIS:\AppPools\$AppPoolName") {
    Remove-WebAppPool -Name $AppPoolName
}
Get-NetFirewallRule -DisplayName $firewallName -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule

$resolvedWebRoot = [System.IO.Path]::GetFullPath($WebRoot)
if ($resolvedWebRoot.StartsWith("C:\inetpub\", [System.StringComparison]::OrdinalIgnoreCase) -and
    (Test-Path -LiteralPath $resolvedWebRoot)) {
    Remove-Item -LiteralPath $resolvedWebRoot -Recurse -Force
}

if ($RemoveData) {
    $resolvedDataRoot = [System.IO.Path]::GetFullPath($DataRoot)
    if (-not $resolvedDataRoot.StartsWith("C:\ProgramData\MECMHealthMonitor", [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove a data path outside C:\ProgramData\MECMHealthMonitor."
    }
    if (Test-Path -LiteralPath $resolvedDataRoot) {
        Remove-Item -LiteralPath $resolvedDataRoot -Recurse -Force
    }
}

Write-Host "MECM Health Monitor was removed." -ForegroundColor Green
if (-not $RemoveData) {
    Write-Host "Configuration and logs were preserved at $DataRoot."
}
