/*
  Optional pre-install access check.
  Run in SQL Server Management Studio as the scheduled-task identity.
  The web collector does not require you to maintain a custom SQL query.
*/

SELECT TOP (1) ResourceID, Name0, Site_Code0
FROM dbo.v_R_System;

SELECT TOP (1) *
FROM dbo.v_CH_ClientSummary;

SELECT TOP (1) *
FROM dbo.v_CH_EvalResults;

SELECT TOP (1) TopicType, StateID, StateName
FROM dbo.v_StateNames
WHERE TopicType BETWEEN 1000 AND 1004;

/* Per-DP application/package content status. At least one current-status
   view is required; the message and package views add friendly details. */
IF OBJECT_ID(N'dbo.v_ContentDistributionReport_DP', N'V') IS NOT NULL
    SELECT TOP (1) * FROM dbo.v_ContentDistributionReport_DP;
ELSE IF OBJECT_ID(N'dbo.v_DistributionStatus', N'V') IS NOT NULL
    SELECT TOP (1) * FROM dbo.v_DistributionStatus;

IF OBJECT_ID(N'dbo.v_ContentDistributionMessages', N'V') IS NOT NULL
    SELECT TOP (1) * FROM dbo.v_ContentDistributionMessages;

/* OSD failed-step detail. */
IF OBJECT_ID(N'dbo.v_TaskExecutionStatus', N'V') IS NOT NULL
    SELECT TOP (1) * FROM dbo.v_TaskExecutionStatus;

/* SCCM client-push/client-install state. */
IF OBJECT_ID(N'dbo.v_ClientDeploymentState', N'V') IS NOT NULL
    SELECT TOP (1) * FROM dbo.v_ClientDeploymentState;
