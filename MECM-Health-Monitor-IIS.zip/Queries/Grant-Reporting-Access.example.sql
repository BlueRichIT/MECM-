/*
  EXAMPLE ONLY - run as a SQL administrator after replacing both placeholders.
  This grants the scheduled-task identity read-only access to the reporting
  views used by MECM Health Monitor. It does not grant access to base tables.
*/

USE [CM_ABC];
GO

CREATE USER [CONTOSO\MECMMonitorSvc$] FOR LOGIN [CONTOSO\MECMMonitorSvc$];
GO

GRANT SELECT ON OBJECT::dbo.v_R_System TO [CONTOSO\MECMMonitorSvc$];
GRANT SELECT ON OBJECT::dbo.v_CH_ClientSummary TO [CONTOSO\MECMMonitorSvc$];
GRANT SELECT ON OBJECT::dbo.v_CH_EvalResults TO [CONTOSO\MECMMonitorSvc$];
GRANT SELECT ON OBJECT::dbo.v_StateNames TO [CONTOSO\MECMMonitorSvc$];

/* Optional SQL fallback for active MECM alerts, when this view exists. */
IF OBJECT_ID(N'dbo.v_SMS_Alert', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_SMS_Alert TO [CONTOSO\MECMMonitorSvc$];

/* Optional detailed dashboard features. */
IF OBJECT_ID(N'dbo.v_ContentDistributionReport_DP', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_ContentDistributionReport_DP TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_DistributionStatus', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_DistributionStatus TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_ContentDistributionMessages', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_ContentDistributionMessages TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_Package', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_Package TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_SMSPackage', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_SMSPackage TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_TaskExecutionStatus', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_TaskExecutionStatus TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_Advertisement', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_Advertisement TO [CONTOSO\MECMMonitorSvc$];
IF OBJECT_ID(N'dbo.v_ClientDeploymentState', N'V') IS NOT NULL
    GRANT SELECT ON OBJECT::dbo.v_ClientDeploymentState TO [CONTOSO\MECMMonitorSvc$];
GO
